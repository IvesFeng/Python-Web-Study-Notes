/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2024-2024. All rights reserved.
 * Description: Source file for SimPost Renderer.
 * Create: 2024-04-18
 */

#include "Schedule/TaskScheduler.h" // 与windows.h有符号冲突，需要放在最前面

#include <QLoggingCategory>
#include <QVariantMap>
#include "Source/Service/Common/Application/Application.h"
#include "Source/SystemFramework/EventDispatcher.h"

#include <set>
#include <string>

#include "PaintEvent.h"
#include "Utils/Utils.h"
#include "Source/Controller/Common/RouterFramework/Operation/RenderOperation.h"
#include "Source/Controller/Common/RouterFramework/Operation/SimPostOperation.h"
#include "Source/Service/Common/Measure.h"   // MSI：快照仅在测量态（data_ 非空）收集

#include "RendererTools.h"
#include "VideoRecorder.h"
#include "SimPostRenderer.h"
#include "SimPostSelector.h"
#include "AnimationRenderer.h"

namespace Painter {
    constexpr size_t MAXIMUM_PROBE_TEXT_NUM = 200;
    // 帧合并间隔(~60fps = 16ms)和缩放防抖间隔(300ms)
    constexpr int FRAME_MERGE_INTERVAL_MS = 16;
    constexpr int ZOOM_DEBOUNCE_INTERVAL_MS = 300;

    // RAII 守卫: 构造时置位 thread_local 标志, 析构时复位, 防止递归调用导致栈溢出/死循环。
    // 用于 OnShowNodesProbeEvent/OnShowElemsProbeEvent/OnRefreshNodesProbeEvent/OnRefreshElemsProbeEvent。
    struct ThreadLocalBoolGuard {
        bool& flag;
        explicit ThreadLocalBoolGuard(bool& f) : flag(f) { flag = true; }
        ~ThreadLocalBoolGuard() { flag = false; }
        ThreadLocalBoolGuard(const ThreadLocalBoolGuard&) = delete;
        ThreadLocalBoolGuard& operator=(const ThreadLocalBoolGuard&) = delete;
    };
}

namespace Painter {
    using Func = void (SimPostRenderer::*)(Base::SimPostMeshType, const Gui::PaintEvent*);
    const static std::unordered_map<Base::Event::Type, Func> eventFuncTable = {
        { Base::Event::Type::SIMPOST_MESH_DATA_CHANGE, &SimPostRenderer::OnMeshDataChangeEvent },
        { Base::Event::Type::SIMPOST_MESH_DATA_VISIBILITY, &SimPostRenderer::OnMeshDataVisibilityEvent },
        { Base::Event::Type::SIMPOST_MESH_DATA_HIGHLIGHT, &SimPostRenderer::OnMeshDataHighlightEvent },
        { Base::Event::Type::SIMPOST_VARIABLE_CHANGE, &SimPostRenderer::OnVariableChangeEvent },
        { Base::Event::Type::SIMPOST_VARIABLE_VISIBILITY, &SimPostRenderer::OnVariableVisibilityEvent },
        { Base::Event::Type::SIMPOST_HIDE_NODES_PROBE, &SimPostRenderer::OnHideNodesProbeEvent },
        { Base::Event::Type::SIMPOST_SHOW_NODES_PROBE, &SimPostRenderer::OnShowNodesProbeEvent },
        { Base::Event::Type::SIMPOST_SET_COLORBAR_TYPE, &SimPostRenderer::OnSetColorBarTypeEvent },
        { Base::Event::Type::SIMPOST_UPDATE_VARIABLE_DEFORMATION, &SimPostRenderer::OnVariableDeformationEvent },
        { Base::Event::Type::SIMPOST_HIGHLIGHT_SELECTED_NODE, &SimPostRenderer::OnSetNodesSelected },
        { Base::Event::Type::SIMPOST_MAX_MIN_LOCATION_SHOW, &SimPostRenderer::OnExtremePointShowEvent },
        { Base::Event::Type::SIMPOST_HIGHLIGHT_SELECTED_ELEM, &SimPostRenderer::OnSetElemsSelected },
        { Base::Event::Type::SIMPOST_HIDE_ELEMENTS_PROBE, &SimPostRenderer::OnHideElemsProbeEvent },
        { Base::Event::Type::SIMPOST_SHOW_ELEMENTS_PROBE, &SimPostRenderer::OnShowElemsProbeEvent },
        { Base::Event::Type::SIMPOST_PROBE_LABEL_HIGHLIGHT, &SimPostRenderer::OnProbeLabelHighlight },
        { Base::Event::Type::SEND_ANIMATION_NAMES, &SimPostRenderer::OnAnimationVariablesEvent },
        { Base::Event::Type::SEND_PROGRESS_INDEX, &SimPostRenderer::OnAnimationProgressIndexEvent },
        { Base::Event::Type::EXPORT_ANIMATION_DATA, &SimPostRenderer::OnAnimationExportEvent },
    };

    SimPostRenderer::VariableRepresentation GetVariableRepresentation(const std::string& name,
        Base::VariableComponentType type, int componentNum)
    {
        if (type == Base::VariableComponentType::INVALID) {
            return { name, 0, vtkScalarsToColors::COMPONENT };
        }
        if (type == Base::VariableComponentType::MAG) {
            return { name, -1, vtkScalarsToColors::MAGNITUDE };
        }
        if (type == Base::VariableComponentType::X && componentNum >= 1) { // 1 : 一维数据
            return { name, 0, vtkScalarsToColors::COMPONENT };
        }
        if (type == Base::VariableComponentType::Y && componentNum >= 2) { // 2 : 二维数据
            return { name, 1, vtkScalarsToColors::COMPONENT };
        }
        if (type == Base::VariableComponentType::Z && componentNum >= 3) { // 3 : 三维数据
            return { name, 2, vtkScalarsToColors::COMPONENT };
        }
        return {};
    }

    std::string FillNodeProbeTextString(const Base::SimPostNodeProbeData& data, bool renderVariable)
    {
        std::string textString(" ");
        if (renderVariable && data.contourValid) {
            for (int i = 0; i < data.contour.size(); i++) {
                textString += App::Utils::MagnitudeAdaptiveToString(data.contour[i].second).toStdString();
                if (i != data.contour.size() - 1) {
                    textString += " , ";
                }
            }
            textString += " \n ";
        }
        textString += "N ";
        textString += std::to_string(data.nodeId);
        textString += " ";
        return textString;
    }

    std::string FillElemProbeTextString(const Base::SimPostElemProbeData& data, bool renderVariable)
    {
        std::string textString(" ");
        if (renderVariable && data.contourValid) {
            for (int i = 0; i < data.contour.size(); i++) {
                textString += App::Utils::MagnitudeAdaptiveToString(data.contour[i].second).toStdString();
                if (i != data.contour.size() - 1) {
                    textString += " , ";
                }
            }
            textString += " \n ";
        }
        textString += "E ";
        textString += std::to_string(data.elemId);
        textString += " ";
        return textString;
    }

}

Painter::SimPostRenderer::SimPostRenderer(VTKPainterPtr painter)
    : painter_(painter),
    scalarBarActor_(vtkSmartPointer<ScalarBarActor>::New()),
    informationText_(std::make_shared<SimPostInformationText>())
{
    scalarBarActor_->SetVectorMode(vtkScalarsToColors::COMPONENT);
    scalarBarActor_->SetNanColor(SimPostRenderModel::GetMeshColor());
    scalarBarActor_->SetEditRecordClearMsg(QStringLiteral(u"云图梯度编辑记录与当前云图梯度范围存在冲突，编辑记录已被清理。"));
    scalarBarActor_->SetEditLabelValueFailMsg(QStringLiteral(u"云图梯度编辑失败，可能与现有云图梯度范围存在冲突，请检查后重试。"));
    frameMergeTimer_.setSingleShot(false);
    frameMergeTimer_.setInterval(FRAME_MERGE_INTERVAL_MS);
    frameMergeTimer_.connect(&frameMergeTimer_, &QTimer::timeout, [this]() { UpdateAllOverlayAnchors(); });
    zoomDebounceTimer_.setSingleShot(true);
    zoomDebounceTimer_.setInterval(ZOOM_DEBOUNCE_INTERVAL_MS);
    zoomDebounceTimer_.connect(&zoomDebounceTimer_, &QTimer::timeout, [this]() { RelayoutAllOverlays(); });
}

Painter::SimPostRenderer::~SimPostRenderer()
{
    frameMergeTimer_.stop();
    zoomDebounceTimer_.stop();
}

QWidget* Painter::SimPostRenderer::GetPainterWidget() const
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter, nullptr);
    return painter->GetPainterWidget();
}

void Painter::SimPostRenderer::Render(const Gui::PaintEvent* event)
{
    if (event == nullptr) {
        return;
    }
    if (event->GetType() == Base::Event::Type::PROJECT_PICKUP_MODE) {
        return UpdatePickupMode();
    }
    if (event->GetType() == Base::Event::Type::PROJECT_MESH_DISPLAY_MODE) {
        return UpdateDisplayMode();
    }
    if (event->GetType() == Base::Event::Type::SIMPOST_VIEW_STATUS_CHANGE) {
        return OnRenderStatusChangeEvent(event);
    }
    if (event->GetType() == Base::Event::Type::SIMPOST_NODE_PROBE_VISIBILITY) {
        return OnNodeProbeVisibilityEvent(event);
    }
    if (event->GetType() == Base::Event::Type::SIMPOST_NODES_CLEAR_RENDER) {
        return ClearNodeSelection();
    }
    if (event->GetType() == Base::Event::Type::RENDER_MESH_RENDER_VIEW_CONTROL_EVENT) {
        return OnMeshRenderViewControlEvent(event);
    }
    const Gui::SimPostPaintEvent* simpostEvent = dynamic_cast<const Gui::SimPostPaintEvent*>(event);
    if (simpostEvent == nullptr || simpostEvent->GetSimPostItemType() == Base::SimPostMeshType::INVALID) {
        return;
    }
    auto iter = eventFuncTable.find(event->GetType());
    if (iter == eventFuncTable.end() || iter->second == nullptr) {
        return;
    }
    (this->*iter->second)(simpostEvent->GetSimPostItemType(), event);
}

void Painter::SimPostRenderer::OnRenderStatusChangeEvent(const Gui::PaintEvent* event)
{
    const Gui::SimPostViewStateChangeEvent* postEvent = dynamic_cast<const Gui::SimPostViewStateChangeEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    Base::PostViewState viewState = postEvent->GetPostViewState();
    if (viewState == Base::PostViewState::POST_VIEW || viewState == Base::PostViewState::POST_VIEW_WITH_GEOM) {
        StartPostViewRender();
    } else {
        EndPostViewRender();
    }
    TryRender(painter_);
}

void Painter::SimPostRenderer::OnNodeProbeVisibilityEvent(const Gui::PaintEvent* event)
{
    const Gui::SimPostNodeProbeVisibilityEvent* postEvent
        = dynamic_cast<const Gui::SimPostNodeProbeVisibilityEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    SetShowingProbes(postEvent->GetIsShow());
    TryRender(painter_);
}

void Painter::SimPostRenderer::OnMeshRenderViewControlEvent(const Gui::PaintEvent* event)
{
    VTKPainterPtr painterPtr = painter_.lock();
    PTR_ASSERT_RETURN(painterPtr);
    if (painterPtr->GetPainterStatus().postViewState == Base::PostViewState::PRE_VIEW) {
        return;
    }
    const Gui::MeshRenderViewControlEvent *controlEvent =
        dynamic_cast<const Gui::MeshRenderViewControlEvent *>(event);
    PTR_ASSERT_RETURN(controlEvent);
    Gui::MeshRenderViewControlEvent::RenderControlType type = controlEvent->GetRenderType();
    switch (type) {
        case Gui::MeshRenderViewControlEvent::RenderControlType::DISPLAY_ALL:
            return ShowAllElems();
        case Gui::MeshRenderViewControlEvent::RenderControlType::EXPAND_VISIBLE:
            return ExpandVisibleElems();
        case Gui::MeshRenderViewControlEvent::RenderControlType::REVERSE_CONCEALED:
            return ReverseVisibleElems();
        default:
            break;
    }
}


void Painter::SimPostRenderer::OnMeshDataChangeEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimPostMeshDataChangeEvent* postEvent = dynamic_cast<const Gui::SimPostMeshDataChangeEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    bool changed = false;
    bool isDeleteObject = postEvent->GetResetFlag();
    if (isDeleteObject) {
        changed = renderModel->DelDataObject(postEvent->GetKey());
    } else {
        if (type == Base::SimPostMeshType::SIMMESH_MESH && renderModel->AnyDataArrayNotCleaned()) {
            qCritical(UI) << "SimPostRenderer not all data array cleaned.";
            return;
        }
        vtkDataObject* vtkData = static_cast<vtkDataObject*>(postEvent->GetVtkObject());
        changed = renderModel->AddDataObject(postEvent->GetKey(), vtkData,
            postEvent->GetNodeIdsArrayName(), postEvent->GetElemIdsArrayName());
    }
    ClearNodeSelection();
    ClearElemSelection();
    if (changed) {
        ClearDeformation(type);
        VTKPainterPtr painter = painter_.lock();
        PTR_ASSERT_RETURN(painter);
        painter->TryResetCameraBeforeRender();
        TryRender(painter_);
    } else {
        isDeleteObject ? qWarning() << "SimPostRenderer del data object failed."
            : qWarning() << "SimPostRenderer add data object failed.";
    }
}

void Painter::SimPostRenderer::OnMeshDataVisibilityEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimPostMeshDataVisibilityEvent* postEvent =
        dynamic_cast<const Gui::SimPostMeshDataVisibilityEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    // MSI（后处理）：隐藏/显示会改变可见集，测量高亮需要在下次测量入口按 data_ 重建
    measureHighlightDirty_ = true;
    if (postEvent->GetVisibility()) {
        renderModel->ShowDataObejct(postEvent->GetKey());
    } else {
        renderModel->HideDataObejct(postEvent->GetKey());
    }
    UpdateProbeDatas(type);
    TryRender(painter_);
}

void Painter::SimPostRenderer::OnMeshDataHighlightEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimPostMeshDataHighlightEvent* postEvent =
        dynamic_cast<const Gui::SimPostMeshDataHighlightEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    std::map<Base::ItemInfo, Base::SelectedStatus> itemsInfo = postEvent->GetSelectInfos();
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    for (auto iter = itemsInfo.begin(); iter != itemsInfo.end(); iter++) {
        if (iter->second == Base::SelectedStatus::NONE) {
            // MSI（后处理）：体级高亮被清掉 → 置脏，下次测量入口重建
            measureHighlightDirty_ = true;
            renderModel->SubHighlightObject(iter->first);
        } else {
            renderModel->AddHighlightObject(iter->first);
        }
    }
    TryRender(painter_);
}

void Painter::SimPostRenderer::OnVariableChangeEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimPostVariableChangeEvent* postEvent = dynamic_cast<const Gui::SimPostVariableChangeEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    bool changed = false;
    bool isDetach = postEvent->GetIsDetach();
    Base::VariableDataType variableDataType = postEvent->GetVarDataType();
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    if (isDetach) {
        switch (variableDataType) {
            case Base::VariableDataType::POINT:
                changed = renderModel->DetachPointDataArray(postEvent->GetName());
                break;
            case Base::VariableDataType::CELL:
                changed = renderModel->DetachCellDataArray(postEvent->GetName());
                break;
            case Base::VariableDataType::NONE_AVERAGE:
                changed = renderModel->DetachNonAverageDataArray(postEvent->GetName());
                break;
            default: break;
        }
    } else {
        switch (variableDataType) {
            case Base::VariableDataType::POINT:
                changed = renderModel->AttachPointDataArray(postEvent->GetName(),
                    postEvent->GetDataArrays(), postEvent->GetIsAddFieldData());
                break;
            case Base::VariableDataType::CELL:
                changed = renderModel->AttachCellDataArray(postEvent->GetName(),
                    postEvent->GetDataArrays(), postEvent->GetIsAddFieldData());
                break;
            case Base::VariableDataType::NONE_AVERAGE:
                changed = renderModel->AttachNonAverageDataArray(postEvent->GetName(),
                    postEvent->GetDataArrays(), postEvent->GetIsAddFieldData());
                break;
            default: break;
        }
    }
    if (!changed) {
        QString operationType = isDetach ? "detach" : "attach";
        qWarning() << QStringLiteral("SimPostRenderer %1 %2 data object failed.")
            .arg(operationType).arg(QString(postEvent->GetName().c_str()));
    }
    TryRender(painter_);
}

void Painter::SimPostRenderer::OnVariableVisibilityEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimPostVariableVisibilityEvent* postEvent =
        dynamic_cast<const Gui::SimPostVariableVisibilityEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    DomainModel& domain = GetOrCreateDomainModel(type);
    VariableStatus& variableStatus = domain.variableStatus_;
    bool showVariable = postEvent->GetIsShow();
    variableStatus.name_ = showVariable ? postEvent->GetVarName() : "";
    variableStatus.title_ = showVariable ? postEvent->GetTitle() : "";
    variableStatus.type_ = showVariable ? postEvent->GetVarDataType() : Base::VariableDataType::INVALID;
    variableStatus.component_ = showVariable ? postEvent->GetVariableComponentType()
        : Base::VariableComponentType::INVALID;
    variableStatus.textInfos_ = showVariable ? postEvent->GetTextInfos()
        : std::vector<std::pair<std::string, std::string>>();
    if (domain.animationStatus_.playing_ && !domain.animationStatus_.pausing_) {
        domain.animationStatus_.updateBlocked_ = true;
        return;
    }
    ShowDataArray(type, variableStatus.type_, variableStatus.name_,
        variableStatus.component_, variableStatus.title_, variableStatus.textInfos_);
    UpdateProbeDatas(type);
    TryRender(painter_);
}

void Painter::SimPostRenderer::OnVariableDeformationEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimPostUpdateVariableDeformation* postEvent =
        dynamic_cast<const Gui::SimPostUpdateVariableDeformation*>(event);
    PTR_ASSERT_RETURN(postEvent);
    const Base::VariableDeformationCtrl variableDeformationCtrl = postEvent->GetVariableDeformationCtrl();
    DomainModel& domain = GetOrCreateDomainModel(type);
    DeformationStatus& deformationStatus = domain.deformationStatus_;
    deformationStatus.type_ = variableDeformationCtrl.deformationType;
    deformationStatus.scale_ = variableDeformationCtrl.scale;
    deformationStatus.name_ = postEvent->GetVarName();
    if (domain.animationStatus_.playing_ && !domain.animationStatus_.pausing_) {
        domain.animationStatus_.updateBlocked_ = true;
    } else {
        RenderModelDeformation(type, deformationStatus.name_);
        UpdateProbeDatas(type);
    }
    UpdateDisplayMode();
}

void Painter::SimPostRenderer::OnAnimationVariablesEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    auto animationRenderer = GetConcreteRenderer<AnimationRenderer>(GetAllRenderers()).lock();
    PTR_ASSERT_RETURN(animationRenderer);
    const Gui::SimSendAnimationNamesEvent* postEvent =
        dynamic_cast<const Gui::SimSendAnimationNamesEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    DomainModel& domain = GetOrCreateDomainModel(type);
    AnimationStatus& animationStatus = domain.animationStatus_;
    if (animationStatus.readyToPlay_) {
        return;
    }
    animationStatus.title_ = postEvent->GetVarType();
    animationStatus.dataType_ = postEvent->GetVarDataType();
    animationStatus.componentType_ = postEvent->GetVarCompType();
    animationStatus.default_ = postEvent->GetIndex();
    animationStatus.current_ = postEvent->GetIndex();
    animationStatus.frames_ = postEvent->GetInfos();
    if (animationStatus.current_ >= animationStatus.frames_.size() || !CheckAnimationRange(domain)) {
        return;
    }
    animationStatus.readyToPlay_ = true;
}

void Painter::SimPostRenderer::OnAnimationProgressIndexEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SendAnimationProgressIndexEvent* postEvent
        = dynamic_cast<const Gui::SendAnimationProgressIndexEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    AnimationStatus& animationStatus = GetOrCreateDomainModel(type).animationStatus_;
    size_t frame = postEvent->GetProgressIndex();
    if (!animationStatus.readyToPlay_ || (animationStatus.playing_ && !animationStatus.pausing_)
        || frame >= animationStatus.frames_.size()) {
        return;
    }

    animationStatus.current_ = frame;
    RenderCurrentAnimationFrame(type);
    TryRender(painter_);
}

void Painter::SimPostRenderer::OnAnimationExportEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimExportAnimationDataEvent* animationEvent
        = dynamic_cast<const Gui::SimExportAnimationDataEvent*>(event);
    PTR_ASSERT_RETURN(animationEvent);
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);

    vtkRenderWindow* renderWindow = painter->GetRenderWindow();

    DomainModel& domain = GetOrCreateDomainModel(type);
    AnimationStatus& animationStatus = domain.animationStatus_;
    if (!animationStatus.readyToPlay_) {
        return;
    }
    auto videoRecorder = GetConcreteRenderer<VideoRecorder>(GetAllRenderers()).lock();
    PTR_ASSERT_RETURN(videoRecorder);
    if (!videoRecorder->StartRecording(animationEvent->GetFilePath(), animationEvent->GetFrameRate())) {
        return;
    }

    AnimationStatus animationStatusBackup = animationStatus;
    scalarBarActor_->UpdateScalarRangeValue(animationStatus.minVal_, animationStatus.maxVal_);
    animationStatus.playing_ = true;
    animationStatus.pausing_ = false;
    scalarBarActor_->SetRangeLocked(animationStatus.playing_);

    for (size_t frame = 0; frame < animationStatus.frames_.size(); ++frame) {
        animationStatus.current_ = frame;
        RenderCurrentAnimationFrame(type);
        renderWindow->Render();
    }
    videoRecorder->EndRecording();
    // 加提示
    QFileInfo fileInfo(animationEvent->GetFilePath().c_str());
    if (fileInfo.exists() && fileInfo.isFile()) {
        qint64 size = fileInfo.size(); // 获取文件大小（字节为单位）
        double sizeInMB = static_cast<double>(size) / (1024 * 1024); // 1024 转换为MB
        qInfo(UI) << qApp->translate("SimPostRenderer", "%1 Animation file exported successfully, size: %2M.").
            arg(animationEvent->GetFilePath().c_str()).arg(QString::number(sizeInMB, 'f', 2)); // 2位有效数字
    }
    animationStatus = animationStatusBackup;
    scalarBarActor_->SetRangeLocked(animationStatus.playing_);
    RenderCurrentAnimationFrame(type);
}

void Painter::SimPostRenderer::OnHideNodesProbeEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimPostHideNodesProbeEvent* postEvent = dynamic_cast<const Gui::SimPostHideNodesProbeEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    std::vector<SelectionData> selectionDatas;
    for (const auto&[itemId, pointId] : postEvent->GetHideNodeDatas()) {
        selectionDatas.emplace_back(SelectionData{ Base::ItemInfo(itemId, Base::ItemType::SIM_POST), { pointId } });
    }
    // An empty HIDE request means clear all probes of this type.
    // Keep empty-selection semantics unchanged for other selection operations.
    if (selectionDatas.empty()) {
        GetOrCreateDomainModel(type).renderModel_->ClearNodeSelection();
    } else {
        SetNodesNotSelected(type, selectionDatas);
    }
    UpdateProbeText(type);
    UpdateExtremePointProbe(type);
    TryRender(painter_);
}

void Painter::SimPostRenderer::OnHideElemsProbeEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimPostHideElementsProbeEvent* postEvent =
        dynamic_cast<const Gui::SimPostHideElementsProbeEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    std::vector<SelectionData> selectionDatas;
    for (const auto&[itemId, cellId] : postEvent->GetHideElementDatas()) {
        selectionDatas.emplace_back(SelectionData{ Base::ItemInfo(itemId, Base::ItemType::SIM_POST), { cellId } });
    }
    // An empty HIDE request means clear all probes of this type.
    // Keep empty-selection semantics unchanged for other selection operations.
    if (selectionDatas.empty()) {
        GetOrCreateDomainModel(type).renderModel_->ClearElemSelection();
    } else {
        SetElemsNotSelected(type, selectionDatas);
    }
    UpdateProbeText(type);
    UpdateExtremePointProbe(type);
    TryRender(painter_);
}

void Painter::SimPostRenderer::ResendRefilledNodeProbeDatas(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionDatas)
{
    // 抽取自 OnShowNodesProbeEvent 的 needRefill 分支, 降低主函数嵌套深度(G.FUN.01-CPP: 嵌套深度<=4)。
    // 仅在需要补全时(Python回放路径)重发已补全的 SHOW_NODES_PROBE 事件给表格; 3D拾取路径(pointId已>=0)不重发,避免表格重复追加。
    VTKPainterPtr painter = painter_.lock();
    if (!painter) {
        return;
    }
    std::vector<Base::SimPostNodeProbeData> nodeProbeDatas = GetNodeProbeDatas(type, selectionDatas);
    if (nodeProbeDatas.empty()) {
        return;
    }
    ROUTER_NO_RECORD(Route::SimPostOperationType::SHOW_NODES_PROBE)::Route(painter->GetProjectID(),
        GetOrCreateDomainModel(type).renderModel_->GetColorArrayName(), true, nodeProbeDatas);
}

void Painter::SimPostRenderer::OnShowNodesProbeEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    // 本处理器会被 SendNodeProbeDatas(经 ROUTER(SHOW_NODES_PROBE) → Service → SendEvent) 间接触发;
    // thread_local guard 防止递归调用导致栈溢出/死循环。与 OnRefreshNodesProbeEvent 范式一致。
    static thread_local bool inShowNodesProbe = false;
    if (inShowNodesProbe) {
        return;
    }
    // R7.7 RAII: 用 ThreadLocalBoolGuard 替代手写 inShowNodesProbe = true/false, 防止异常/early-return 导致标志泄漏。
    ThreadLocalBoolGuard guard(inShowNodesProbe);
    const Gui::SimPostShowNodesProbeEvent* postEvent = dynamic_cast<const Gui::SimPostShowNodesProbeEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    std::vector<SelectionData> selectionDatas;
    // 检测是否需要补全(Python API回放路径: pointId<0 但 nodeId有效)
    bool needRefill = false;
    for (const auto& probeData : postEvent->GetShowNodeDatas()) {
        vtkIdType pointId = probeData.pointId;
        Base::ItemInfo itemInfo = Base::ItemInfo(probeData.itemInfo.itemId, Base::ItemType::SIM_POST);
        // Python API 回放路径: pointId=-1 但 nodeId 有效时, 从渲染模型反查 pointId
        if (pointId < 0 && probeData.nodeId != ::Mesh::INVALID_NODE_ID) {
            needRefill = true;
            Base::ItemInfo foundKey;
            pointId = renderModel->GetPointIdByNodeId(probeData.nodeId, &foundKey);
            if (pointId >= 0) {
                itemInfo = foundKey;
            }
        }
        if (pointId < 0) {
            continue;
        }
        selectionDatas.emplace_back(SelectionData{ itemInfo, { pointId } });
    }
    if (selectionDatas.empty()) {
        return;
    }
    if (postEvent->GetIsSelect()) {
        SetNodesSelected(type, selectionDatas);
        if (needRefill) {
            ResendRefilledNodeProbeDatas(type, selectionDatas);
        }
    } else {
        SetNodesNotSelected(type, selectionDatas);
    }
    UpdateProbeText(type);
    UpdateExtremePointProbe(type);
}

void Painter::SimPostRenderer::ResendRefilledElemProbeDatas(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionDatas)
{
    // 抽取自 OnShowElemsProbeEvent 的 needRefill 分支, 降低主函数嵌套深度(G.FUN.01-CPP: 嵌套深度<=4)。
    // 仅在需要补全时(Python回放路径)重发已补全的 SHOW_ELEMENTS_PROBE 事件给表格; 3D拾取路径(cellId已>=0)不重发,避免表格重复追加。
    VTKPainterPtr painter = painter_.lock();
    if (!painter) {
        return;
    }
    std::vector<Base::SimPostElemProbeData> elementProbeDatas = GetElemProbeDatas(type, selectionDatas);
    if (elementProbeDatas.empty()) {
        return;
    }
    ROUTER_NO_RECORD(Route::SimPostOperationType::SHOW_ELEMENTS_PROBE)::Route(painter->GetProjectID(),
        GetOrCreateDomainModel(type).renderModel_->GetColorArrayName(), true, elementProbeDatas);
}

void Painter::SimPostRenderer::OnShowElemsProbeEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    // 同 OnShowNodesProbeEvent: 防止 SendElementProbeDatas(经 ROUTER(SHOW_ELEMENTS_PROBE)) 间接触发导致的循环。
    static thread_local bool inShowElemsProbe = false;
    if (inShowElemsProbe) {
        return;
    }
    // R7.7 RAII: 用 ThreadLocalBoolGuard 替代手写 inShowElemsProbe = true/false, 防止异常/early-return 导致标志泄漏。
    ThreadLocalBoolGuard guard(inShowElemsProbe);
    const Gui::SimPostShowElementsProbeEvent* postEvent =
        dynamic_cast<const Gui::SimPostShowElementsProbeEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    std::vector<SelectionData> selectionDatas;
    // 检测是否需要补全(Python API回放路径: cellId<0 但 elemId有效)
    bool needRefill = false;
    for (const auto& probeData : postEvent->GetShowElementDatas()) {
        vtkIdType cellId = probeData.cellId;
        Base::ItemInfo itemInfo = Base::ItemInfo(probeData.itemInfo.itemId, Base::ItemType::SIM_POST);
        // Python API 回放路径: cellId=-1 但 elemId 有效时, 从渲染模型反查 cellId
        if (cellId < 0 && probeData.elemId != ::Mesh::INVALID_ELEM_ID) {
            needRefill = true;
            Base::ItemInfo foundKey;
            cellId = renderModel->GetCellIdByElemId(probeData.elemId, &foundKey);
            if (cellId >= 0) {
                itemInfo = foundKey;
            }
        }
        if (cellId < 0) {
            continue;
        }
        selectionDatas.emplace_back(SelectionData{ itemInfo, { cellId } });
    }
    if (selectionDatas.empty()) {
        return;
    }
    if (postEvent->GetIsSelect()) {
        SetElemsSelected(type, selectionDatas);
        if (needRefill) {
            ResendRefilledElemProbeDatas(type, selectionDatas);
        }
    } else {
        SetElemsNotSelected(type, selectionDatas);
    }
    UpdateProbeText(type);
    UpdateExtremePointProbe(type);
}

void Painter::SimPostRenderer::OnSetColorBarTypeEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimPostSetColorBarTypeEvent* postEvent = dynamic_cast<const Gui::SimPostSetColorBarTypeEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    const Base::ColorBarType colorBarType = postEvent->GetColorBarType();
    if (colorBarType == Base::ColorBarType::ISOGRAM) {
        SetInterpolateScalarsBeforeMapping(true);
    } else if (colorBarType == Base::ColorBarType::SMOOTH_TRANSITION) {
        SetInterpolateScalarsBeforeMapping(false);
    }
}

std::vector<Base::ItemInfo> Painter::SimPostRenderer::GetHighlightItems(Base::SimPostMeshType type)
{
    return GetOrCreateDomainModel(type).renderModel_->GetVisibleHighlightObjects();
}

std::vector<Base::ItemInfo> Painter::SimPostRenderer::GetItemsInBox(Base::SimPostMeshType type,
    const Base::BBox2D& selectBox, const Matrix4D& matrix)
{
    return GetOrCreateDomainModel(type).renderModel_->GetItemsInBox(selectBox, matrix);
}

std::vector<Painter::SimPostRenderer::SelectionData> Painter::SimPostRenderer::GetNodesInBox(
    Base::SimPostMeshType type, const Base::BBox2D& selectBox, const Matrix4D& matrix)
{
    return GetOrCreateDomainModel(type).renderModel_->GetNodesInBox(selectBox, matrix);
}

std::vector<Painter::SimPostRenderer::SelectionData> Painter::SimPostRenderer::GetElemsInBox(
    Base::SimPostMeshType type, const Base::BBox2D& selectBox, const Matrix4D& matrix)
{
    return GetOrCreateDomainModel(type).renderModel_->GetElemsInBox(selectBox, matrix);
}

std::vector<Painter::SimPostRenderer::SelectionData> Painter::SimPostRenderer::GetSurfaceNodesInBox(
    Base::SimPostMeshType type, const Base::BBox2D& selectBox, const Matrix4D& matrix)
{
    return GetOrCreateDomainModel(type).renderModel_->GetSurfaceNodesInBox(selectBox, matrix);
}

std::vector<Painter::SimPostRenderer::SelectionData> Painter::SimPostRenderer::GetSurfaceElemsInBox(
    Base::SimPostMeshType type, const Base::BBox2D& selectBox, const Matrix4D& matrix)
{
    return GetOrCreateDomainModel(type).renderModel_->GetSurfaceElemsInBox(selectBox, matrix);
}

vtkDataArray* Painter::SimPostRenderer::GetRealDataArray(Base::SimPostMeshType type, const Base::ItemInfo& key,
    const std::string& arrayName, Base::VariableDataType dataType)
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    if (dataType == Base::VariableDataType::POINT) {
        return renderModel->GetRealPointDataArray(key, arrayName);
    }
    if (dataType == Base::VariableDataType::CELL) {
        return renderModel->GetRealCellDataArray(key, arrayName);
    }
    if (dataType == Base::VariableDataType::NONE_AVERAGE) {
        return renderModel->GetRealNonAverageDataArray(key, arrayName);
    }
    return nullptr;
}

std::vector<Base::SimPostNodeProbeData> Painter::SimPostRenderer::GetNodeProbeDatas(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionData)
{
    const DomainModel& domain = GetOrCreateDomainModel(type);
    return domain.renderModel_->GetNodesProbeData(selectionData);
}

std::vector<Base::SimPostNodeSelectedData> Painter::SimPostRenderer::GetNodeSelectedDatas(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionData)
{
    return GetOrCreateDomainModel(type).renderModel_->GetNodesSelectedData(selectionData);
}

std::vector<Base::SimPostElemProbeData> Painter::SimPostRenderer::GetElemProbeDatas(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionData)
{
    const DomainModel& domain = GetOrCreateDomainModel(type);
    return domain.renderModel_->GetElemsProbeData(selectionData);
}

std::vector<Base::SimPostElemSelectedData> Painter::SimPostRenderer::GetElemSelectedDatas(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionData)
{
    return GetOrCreateDomainModel(type).renderModel_->GetElemsSelectedData(selectionData);
}

bool Painter::SimPostRenderer::SetPreselection(Base::SimPostMeshType type, const Base::ItemInfo& key)
{
    return GetOrCreateDomainModel(type).renderModel_->SetObjectInHover(key);
}

bool Painter::SimPostRenderer::SetNodePreselection(Base::SimPostMeshType type, const Base::ItemInfo& key,
    const std::vector<vtkIdType>& cellIds)
{
    return GetOrCreateDomainModel(type).renderModel_->SetNodesInHover(key, cellIds);
}

bool Painter::SimPostRenderer::SetElemPreselection(Base::SimPostMeshType type, const Base::ItemInfo& key,
    const std::vector<vtkIdType>& cellIds)
{
    return GetOrCreateDomainModel(type).renderModel_->SetElemsInHover(key, cellIds);
}

void Painter::SimPostRenderer::OnSetNodesSelected(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::HighlightSimPostSelectedNodeEvent* postEvent
        = dynamic_cast<const Gui::HighlightSimPostSelectedNodeEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    std::vector<SelectionData> selectionDatas;
    for (const auto&[itemId, pointId] : postEvent->GetNodes()) {
        selectionDatas.emplace_back(SelectionData{ Base::ItemInfo(itemId, Base::ItemType::SIM_POST), { pointId } });
    }
    if (postEvent->GetIsSelected()) {
        SetNodesSelected(type, selectionDatas);
        SendNodeProbeDatas(type, true, selectionDatas);
    } else {
        // MSI（后处理）：节点高亮被清掉（点空白/隐藏等旁观清空都走这里）→ 置脏，
        //   下一次测量入口按 data_ 重建全部测量高亮。
        measureHighlightDirty_ = true;
        // 用户显式去选的对象不再属于"应重建"的集合，从快照里摘掉，避免重建时被复活
        for (const auto &sel : selectionDatas) {
            auto iter = clearedNodeSelection_.find(sel.itemInfo_);
            if (iter == clearedNodeSelection_.end()) {
                continue;
            }
            for (vtkIdType id : sel.topoIds_) {
                iter->second.erase(id);
            }
        }
        SetNodesNotSelected(type, selectionDatas);
        SendNodeProbeDatas(type, false, selectionDatas);
    }
    UpdateProbeText(type);
}

void Painter::SimPostRenderer::OnSetElemsSelected(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::HighlightSimPostSelectedElemEvent* postEvent
        = dynamic_cast<const Gui::HighlightSimPostSelectedElemEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    std::vector<SelectionData> selectionDatas;
    for (const auto&[itemId, cellId] : postEvent->GetElems()) {
        selectionDatas.emplace_back(SelectionData{ Base::ItemInfo(itemId, Base::ItemType::SIM_POST), { cellId } });
    }
    if (postEvent->GetIsSelected()) {
        SetElemsSelected(type, selectionDatas);
        SendElementProbeDatas(type, true, selectionDatas);
    } else {
        // MSI（后处理）：同节点，单元高亮被清掉即置脏
        measureHighlightDirty_ = true;
        // 同节点：显式去选的单元从快照摘掉
        for (const auto &sel : selectionDatas) {
            auto iter = clearedElemSelection_.find(sel.itemInfo_);
            if (iter == clearedElemSelection_.end()) {
                continue;
            }
            for (vtkIdType id : sel.topoIds_) {
                iter->second.erase(id);
            }
        }
        SetElemsNotSelected(type, selectionDatas);
        SendElementProbeDatas(type, false, selectionDatas);
    }
    UpdateProbeText(type);
}

void Painter::SimPostRenderer::OnProbeLabelHighlight(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::ProbeLabelHighlightEvent* postEvent
        = dynamic_cast<const Gui::ProbeLabelHighlightEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    DomainModel& domain = GetOrCreateDomainModel(type);
    if (domain.probeLabelOverlay_ == nullptr) {
        return;
    }
    // 映射 probeIds → labelIds
    std::set<uint64_t> labelIds;
    for (const auto& [itemId, pointOrCellId] : postEvent->GetProbes()) {
        uint64_t labelId = domain.probeLabelOverlay_->FindLabelByProbe(itemId, pointOrCellId);
        if (labelId != 0) {
            labelIds.insert(labelId);
        }
    }
    domain.probeLabelOverlay_->SetHighlighted(labelIds);
    VTKPainterPtr painter = painter_.lock();
    if (painter != nullptr) {
        painter->TryRender();
    }
}

bool Painter::SimPostRenderer::HandleLabelPick(int x, int y)
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter, false);
    // 检查修饰键
    auto* interactor = painter->GetRenderWindowInteractor();
    bool ctrlDown = interactor != nullptr && interactor->GetControlKey() != 0;
    bool shiftDown = interactor != nullptr && interactor->GetShiftKey() != 0;

    // 遍历域模型,尝试拾取标签
    for (auto& [type, domain] : domainModels_) {
        if (domain.probeLabelOverlay_ == nullptr) {
            continue;
        }
        uint64_t labelId = 0;
        if (!domain.probeLabelOverlay_->PickLabelAt(x, y, labelId)) {
            continue;
        }
        // 命中标签:按选择模式更新高亮
        if (ctrlDown) {
            domain.probeLabelOverlay_->ToggleHighlight(labelId);
        } else if (shiftDown) {
            domain.probeLabelOverlay_->RangeHighlight(lastPickedLabelId_, labelId);
        } else {
            domain.probeLabelOverlay_->SetHighlighted({ labelId });
        }
        lastPickedLabelId_ = labelId;

        // 收集同类型高亮 probes,分发表格选择
        auto labelType = domain.probeLabelOverlay_->GetLabelType(labelId);
        if (labelType == ProbeLabelOverlay::LabelType::NODE ||
            labelType == ProbeLabelOverlay::LabelType::ELEM) {
            auto probes = domain.probeLabelOverlay_->GetHighlightedProbes(labelType);
            ROUTER(Route::SimPostOperationType::PICK_PROBE_LABELS)::Route(
                painter->GetProjectID(), probes, labelType == ProbeLabelOverlay::LabelType::NODE);
        }
        painter->TryRender();
        return true;
    }
    return false;
}

void Painter::SimPostRenderer::OnExtremePointShowEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    const Gui::SimMaxMinLocationShowEvent* postEvent
        = dynamic_cast<const Gui::SimMaxMinLocationShowEvent*>(event);
    PTR_ASSERT_RETURN(postEvent);
    bool showMax = postEvent->GetMaxIsShow();
    bool showMin = postEvent->GetMinIsShow();
    if (showMax == showingMaximumPoint_ && showMin == showingMinimumPoint_) {
        return;
    }
    showingMaximumPoint_ = showMax;
    showingMinimumPoint_ = showMin;
    UpdateExtremePointProbe(type);
    TryRender(painter_);
}

bool Painter::SimPostRenderer::SetNodesSelected(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionData)
{
    GetOrCreateDomainModel(type).renderModel_->SetNodesSelected(selectionData);
    TryRender(painter_);
    return true;
}

bool Painter::SimPostRenderer::SetNodesNotSelected(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionData)
{
    GetOrCreateDomainModel(type).renderModel_->SetNodesNotSelected(selectionData);
    TryRender(painter_);
    return true;
}

bool Painter::SimPostRenderer::SetElemsSelected(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionData)
{
    GetOrCreateDomainModel(type).renderModel_->SetElemsSelected(selectionData);
    TryRender(painter_);
    return true;
}

bool Painter::SimPostRenderer::SetElemsNotSelected(Base::SimPostMeshType type,
    const std::vector<SelectionData>& selectionData)
{
    GetOrCreateDomainModel(type).renderModel_->SetElemsNotSelected(selectionData);
    TryRender(painter_);
    return true;
}

bool Painter::SimPostRenderer::SetItemsInSceneSelection(Base::SimPostMeshType type,
    const std::set<Base::ItemInfo>& items)
{
    return GetOrCreateDomainModel(type).renderModel_->SetItemsInSceneSelection(items);
}

bool Painter::SimPostRenderer::SetNodesInSceneSelection(Base::SimPostMeshType type,
    const std::map<Base::ItemInfo, std::vector<vtkIdType>>& cellIds)
{
    return GetOrCreateDomainModel(type).renderModel_->SetNodesInSceneSelection(cellIds);
}

bool Painter::SimPostRenderer::SetElemsInSceneSelection(Base::SimPostMeshType type,
    const std::map<Base::ItemInfo, std::vector<vtkIdType>>& cellIds)
{
    return GetOrCreateDomainModel(type).renderModel_->SetElemsInSceneSelection(cellIds);
}

void Painter::SimPostRenderer::SetInterpolateScalarsBeforeMapping(bool interpolate)
{
    if (interpolateBeforeMapping_ == interpolate) {
        return;
    }
    interpolateBeforeMapping_ = interpolate;
    for (const auto&[key, domain] : domainModels_) {
        domain.renderModel_->SetInterpolateScalarsBeforeMapping(interpolateBeforeMapping_);
    }
    TryRender(painter_);
}

bool Painter::SimPostRenderer::ConsumeMeasureHighlightDirty()
{
    const bool dirty = measureHighlightDirty_;
    measureHighlightDirty_ = false;
    return dirty;
}

void Painter::SimPostRenderer::ClearSelection()
{
    // MSI（后处理）：清选择高亮后，测量数据可能仍保留（ClearByIntent 隔离），
    //   记为脏，下一次测量入口据此按 data_ 重建高亮。
    measureHighlightDirty_ = true;
    if (!showingProbes_) {
        ClearNodeSelection();
        ClearElemSelection();
    }
}

void Painter::SimPostRenderer::ClearNodeSelection()
{
    measureHighlightDirty_ = true;   // MSI（后处理）：清高亮即置脏，供下次测量入口重建
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    for (const auto&[key, domain] : domainModels_) {
        auto selection = domain.renderModel_->GetSelectedNodes(REMOVED_CELL | HIDDEN_CELL);
        // MSI（后处理）：清空前先快照——框选批量只在渲染层选择里，MeasureSubject::data_ 不含它，
        //   下次测量入口重建高亮时靠这份快照把它们一并补回。
        //   仅在测量态（data_ 非空）收集，避免把普通选择当成测量高亮复活。
        if (App::MeasureSubject::GetInstance() != nullptr &&
            App::MeasureSubject::GetInstance()->GetDataSize() > 0) {
            for (const auto &sel : selection) {
                auto &ids = clearedNodeSelection_[sel.itemInfo_];
                ids.insert(sel.topoIds_.begin(), sel.topoIds_.end());
            }
        }
        domain.renderModel_->ClearNodeSelection();
        tf::Taskflow taskFlow;
        taskFlow.emplace([&] {
            UpdateProbeText(key);
        });
        auto taskFuture = TaskScheduler::GetInstance()->RunAsync(std::move(taskFlow));
        // 发送取消选中nodeProbeDatas
        ROUTER(Route::SimPostOperationType::SHOW_NODES_PROBE)::Route(
            painter->GetProjectID(), domain.renderModel_->GetColorArrayName(), false, {});
        TaskScheduler::GetInstance()->Wait(std::move(taskFuture));
        ROUTER(Route::SimPostOperationType::SEND_SELECTED_NODES_DATA)::Route(painter->GetProjectID(),
            GetNodeSelectedDatas(key, selection), false);
    }
}

void Painter::SimPostRenderer::ClearElemSelection()
{
    measureHighlightDirty_ = true;   // MSI（后处理）：清高亮即置脏，供下次测量入口重建
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    for (const auto&[key, domain] : domainModels_) {
        auto selection = domain.renderModel_->GetSelectedElems(REMOVED_CELL | HIDDEN_CELL);
        // MSI（后处理）：同节点——清空前快照，供重建时补回框选批量（仅测量态收集）
        if (App::MeasureSubject::GetInstance() != nullptr &&
            App::MeasureSubject::GetInstance()->GetDataSize() > 0) {
            for (const auto &sel : selection) {
                auto &ids = clearedElemSelection_[sel.itemInfo_];
                ids.insert(sel.topoIds_.begin(), sel.topoIds_.end());
            }
        }
        domain.renderModel_->ClearElemSelection();
        tf::Taskflow taskFlow;
        taskFlow.emplace([&] {
            UpdateProbeText(key);
        });
        auto taskFuture = TaskScheduler::GetInstance()->RunAsync(std::move(taskFlow));

        // 发送取消选中nodeProbeDatas
        ROUTER(Route::SimPostOperationType::SHOW_ELEMENTS_PROBE)::Route(
            painter->GetProjectID(), domain.renderModel_->GetColorArrayName(), false, {});
        TaskScheduler::GetInstance()->Wait(std::move(taskFuture));
        ROUTER(Route::SimPostOperationType::SEND_SELECTED_ELEMENTS_DATA)::Route(painter->GetProjectID(),
            GetElemSelectedDatas(key, selection), false);
    }
}

void Painter::SimPostRenderer::ClearPreselection()
{
    for (const auto&[key, domain] : domainModels_) {
        domain.renderModel_->ClearPreselection();
    }
}

void Painter::SimPostRenderer::ClearDeformation(Base::SimPostMeshType type)
{
    DeformationStatus& deformationStatus = GetOrCreateDomainModel(type).deformationStatus_;
    if (deformationStatus.type_ == Base::VariableDeformationCtrl::DeformationType::INVALID) {
        return;
    }
    deformationStatus.type_ = Base::VariableDeformationCtrl::DeformationType::INVALID;
    deformationStatus.name_ = "";
    deformationStatus.scale_ = 1.f;
    RenderModelDeformation(type, "");
}

void Painter::SimPostRenderer::SetShowingProbes(bool show)
{
    if (showingProbes_ == show) {
        return;
    }
    showingProbes_ = show;
    ClearNodeSelection();
    ClearElemSelection();
}

void Painter::SimPostRenderer::RenderCurrentAnimationFrame(Base::SimPostMeshType type)
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    if (painter->GetPainterStatus().postViewState == Base::PostViewState::PRE_VIEW) {
        return;
    }
    const DomainModel& domain = GetOrCreateDomainModel(type);
    const AnimationStatus& animationStatus = domain.animationStatus_;
    if (animationStatus.current_ >= animationStatus.frames_.size()) {
        return;
    }

    const Base::AnimationInfos& currentFrame = animationStatus.frames_[animationStatus.current_];
    ShowDataArray(type, animationStatus.dataType_, currentFrame.name,
        animationStatus.componentType_, animationStatus.title_, currentFrame.textInfos);
    RenderModelDeformation(type, currentFrame.displacementName);
    if (animationStatus.playing_) {
        UpdateInformationText(currentFrame.textInfos, animationStatus.minVal_, animationStatus.maxVal_);
    }

    UpdateProbeDatas(type);
    ClearPreselection();

    ROUTER(Route::SimPostOperationType::UPDATE_ANIMATION_PROGRESS)::Route(
        painter->GetProjectID(), static_cast<int>(animationStatus.current_));
}

void Painter::SimPostRenderer::OnChange(Base::Subject<RendererEventPtr>&, RendererEventPtr event)
{
    RendererEvent::Type eventType = event->GetType();
    switch (eventType) {
        case Painter::RendererEvent::Type::ANIMATION_START:
            return OnAnimationStartEvent(event);
        case Painter::RendererEvent::Type::ANIMATION_END:
            return OnAnimationEndEvent(event);
        case Painter::RendererEvent::Type::ANIMATION_PAUSE:
            return OnAnimationPauseEvent(event);
        case Painter::RendererEvent::Type::ANIMATION_TICK:
            return OnAnimationTickEvent(event);
        default:
            break;
    }
}

void Painter::SimPostRenderer::OnAnimationStartEvent(RendererEventPtr)
{
    AnimationStatus& animationStatus = GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH).animationStatus_;
    if (!animationStatus.readyToPlay_) {
        return;
    }
    ClearSelection();
    animationStatus.playing_ = true;
    animationStatus.pausing_ = false;
    scalarBarActor_->UpdateScalarRangeValue(animationStatus.minVal_, animationStatus.maxVal_);
    scalarBarActor_->SetRangeLocked(animationStatus.playing_);
    RenderCurrentAnimationFrame(Base::SimPostMeshType::SIMMESH_MESH);
}

void Painter::SimPostRenderer::OnAnimationEndEvent(RendererEventPtr event)
{
    std::shared_ptr<AnimationRenderer::AnimationEndEvent> animationEvent =
        std::dynamic_pointer_cast<AnimationRenderer::AnimationEndEvent>(event);
    PTR_ASSERT_RETURN(animationEvent);
    DomainModel& domain = GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH);
    AnimationStatus& animationStatus = domain.animationStatus_;
    if (!animationStatus.readyToPlay_) {
        return;
    }
    animationStatus.playing_ = false;
    animationStatus.pausing_ = false;
    animationStatus.readyToPlay_ = false;
    scalarBarActor_->SetRangeLocked(animationStatus.playing_);
    if (animationEvent->NeedResetFrame()) {
        animationStatus.current_ = animationStatus.default_;
        RenderCurrentAnimationFrame(Base::SimPostMeshType::SIMMESH_MESH);
    } else if (animationStatus.updateBlocked_) {
        const VariableStatus& variableStatus = domain.variableStatus_;
        ShowDataArray(Base::SimPostMeshType::SIMMESH_MESH, variableStatus.type_, variableStatus.name_,
            variableStatus.component_, variableStatus.title_, variableStatus.textInfos_);
        RenderModelDeformation(Base::SimPostMeshType::SIMMESH_MESH, domain.deformationStatus_.name_);
        UpdateProbeDatas(Base::SimPostMeshType::SIMMESH_MESH);
        animationStatus.updateBlocked_ = false;
    }
}

void Painter::SimPostRenderer::OnAnimationPauseEvent(RendererEventPtr event)
{
    auto pauseEvent = std::dynamic_pointer_cast<AnimationRenderer::AnimationPauseEvent>(event);
    PTR_ASSERT_RETURN(pauseEvent);
    const auto action = pauseEvent->GetAction();
    const auto type = Base::SimPostMeshType::SIMMESH_MESH;
    AnimationStatus& animationStatus = GetOrCreateDomainModel(type).animationStatus_;
    animationStatus.pausing_ = true;
    if (action != Base::AnimationActionType::FIRST_FRAME && action != Base::AnimationActionType::LAST_FRAME) {
        return;
    }

    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    if (!animationStatus.readyToPlay_) {
        // Legacy result.firstFrame/lastFrame may be called before the first play.
        const Base::ItemIdType contourId =
            ROUTER_NO_RECORD(Route::SimPostOperationType::GET_CURRENT_RENDERED_FIELD)
                ::Route(painter->GetProjectID()).GetData<Base::ItemIdType>();
        if (contourId == Base::INVALID_ITEM_ID) {
            qWarning() << "No active contour to jump to an animation frame.";
            return;
        }
        Base::AnimationPrepareResult prep =
            ROUTER_NO_RECORD(Route::SimPostOperationType::PREPARE_ANIMATION_FRAMES)
                ::Route(painter->GetProjectID(), contourId, Base::AnimationFrameSource::BY_TIMES);
        if (!prep.success) {
            qWarning() << "Animation prepare failed:" << prep.errMsg;
            return;
        }
    }
    if (!animationStatus.readyToPlay_ || animationStatus.frames_.empty()) {
        return;
    }
    animationStatus.pausing_ = true;
    animationStatus.current_ = action == Base::AnimationActionType::FIRST_FRAME
        ? 0 : animationStatus.frames_.size() - 1;
    RenderCurrentAnimationFrame(type);
    TryRender(painter_);

    QVariantMap data;
    data.insert("projectId", QVariant::fromValue(painter->GetProjectID()));
    data.insert("index", static_cast<int>(animationStatus.current_));
    App::GetEventDispatcher().SubmitEvent("simpost.animation.frameJumped", data);
}

void Painter::SimPostRenderer::OnAnimationTickEvent(RendererEventPtr)
{
    AnimationStatus& animationStatus = GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH).animationStatus_;
    if (!animationStatus.playing_ || animationStatus.pausing_ || animationStatus.frames_.empty()) {
        return;
    }

    size_t frame = (animationStatus.current_ + 1) % animationStatus.frames_.size();
    if (frame == animationStatus.current_ || frame >= animationStatus.frames_.size()) {
        return;
    }

    animationStatus.current_ = frame;
    RenderCurrentAnimationFrame(Base::SimPostMeshType::SIMMESH_MESH);
}

void Painter::SimPostRenderer::Init()
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    painter->GetRenderWindowInteractor()->AddObserver(
        vtkCommand::WindowResizeEvent, this, &SimPostRenderer::OnWindowResize);
    painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::SCREENSHOT_EVENT,
        this, &SimPostRenderer::OnWindowResize);
    painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::SELECTION_CLEAR_EVENT,
        this, &SimPostRenderer::ClearSelection);
    painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::PRESELECTION_CLEAR_EVENT,
        this, &SimPostRenderer::ClearPreselection);
    painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::START_ROTATE_OR_PAN_EVENT,
        this, &SimPostRenderer::OnStartRotateOrPan);
    painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::END_ROTATE_OR_PAN_EVENT,
        this, &SimPostRenderer::OnEndRotateOrPan);
    painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::START_ZOOM_EVENT,
        this, &SimPostRenderer::OnStartZoom);
    painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::END_ZOOM_EVENT,
        this, &SimPostRenderer::OnEndZoom);

    // 注册标签拾取回调:2D overlay 标签命中时拦截 3D 拾取
    painter->GetInteractor()->SetLabelPickCallback(
        [this](int x, int y) mutable { return HandleLabelPick(x, y); });

    scalarBarActor_->SetPainter(painter);

    auto animationRenderer = GetConcreteRenderer<AnimationRenderer>(GetAllRenderers()).lock();
    PTR_ASSERT_RETURN(animationRenderer);
    animationRenderer->Attach(this);
}

void Painter::SimPostRenderer::UpdatePickupMode()
{
    VTKPainterPtr painterPtr = painter_.lock();
    PTR_ASSERT_RETURN(painterPtr);
    Base::PickUpMode mode = painterPtr->GetPainterStatus().pickUpMode;
    bool isPostView = painterPtr->GetPainterStatus().postViewState == Base::PostViewState::POST_VIEW ||
        painterPtr->GetPainterStatus().postViewState == Base::PostViewState::POST_VIEW_WITH_GEOM;
    bool cellPickble = (mode == Base::PickUpMode::DEFAULT ||
        mode == Base::PickUpMode::GEOM_BODY || mode == Base::PickUpMode::MESH_BEAM);
    for (const auto&[type, domain] : domainModels_) {
        domain.renderModel_->SetPointPickable(isPostView && mode == Base::PickUpMode::MESH_POINT);
        domain.renderModel_->SetCellPickable(isPostView && cellPickble);
    }
}

void Painter::SimPostRenderer::UpdateDisplayMode()
{
    VTKPainterPtr painterPtr = painter_.lock();
    PTR_ASSERT_RETURN(painterPtr);
    Base::MeshDisplayMode mode = painterPtr->GetPainterStatus().meshDisplayMode;
    bool isPostView = painterPtr->GetPainterStatus().postViewState == Base::PostViewState::POST_VIEW ||
        painterPtr->GetPainterStatus().postViewState == Base::PostViewState::POST_VIEW_WITH_GEOM;
    for (const auto&[type, domain] : domainModels_) {
        domain.renderModel_->SetPolyVisibility(isPostView);
        domain.renderModel_->SetLineVisibility(isPostView && mode == Base::MeshDisplayMode::MESH_OUTLINE_WITH_SURFACE);
        domain.renderModel_->SetOriginalOutlineVisibility(isPostView &&
            domain.deformationStatus_.type_ == Base::VariableDeformationCtrl::DeformationType::CONTOUR_LINE);
        domain.renderModel_->SetOriginalMeshEdgeVisibility(isPostView &&
            domain.deformationStatus_.type_ == Base::VariableDeformationCtrl::DeformationType::GRID_LINE);
        domain.renderModel_->SetPolyEdgeVisibility(isPostView
            && mode != Base::MeshDisplayMode::MESH_OUTLINE_WITH_SURFACE
            && mode != Base::MeshDisplayMode::MESH_SURFACE);
        domain.renderModel_->SetFreeVertVisibility(isPostView);
        domain.renderModel_->SetFreeLineVisibility(isPostView);
        domain.renderModel_->SetHighlightVisibility(isPostView);
    }
}

void Painter::SimPostRenderer::UpdateProbeText(Base::SimPostMeshType type)
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    ProbeLabelOverlayPtr overlay = GetOrCreateDomainModel(type).probeLabelOverlay_;
    PTR_ASSERT_RETURN(overlay);
    if (painter->GetPainterStatus().postViewState == Base::PostViewState::PRE_VIEW) {
        overlay->SetVisibility(false);
        return;
    }
    if (!showingProbes_) {
        overlay->SetLabelTypeVisibility(ProbeLabelOverlay::LabelType::NODE, false);
        overlay->SetLabelTypeVisibility(ProbeLabelOverlay::LabelType::ELEM, false);
        return;
    }

    const DomainModel& domain = GetOrCreateDomainModel(type);
    SimPostRenderModelPtr renderModel = domain.renderModel_;
    std::vector<SelectionData> selectedNodes = renderModel->GetSelectedNodes(REMOVED_CELL | HIDDEN_CELL);
    std::vector<Base::SimPostNodeProbeData> nodeProbeDatas = GetNodeProbeDatas(type, selectedNodes);
    std::vector<Base::Vec3> nodeCoordinates = renderModel->GetNodesCoordinate(selectedNodes, true, true);
    if (nodeProbeDatas.size() != nodeCoordinates.size()) {
        return;
    }
    std::vector<SelectionData> selectedElems = renderModel->GetSelectedElems(REMOVED_CELL | HIDDEN_CELL);
    std::vector<Base::SimPostElemProbeData> elemProbeDatas = GetElemProbeDatas(type, selectedElems);
    std::vector<Base::Vec3> elemCoordinates = renderModel->GetElemsCoordinate(selectedElems, true, true);
    if (elemProbeDatas.size() != elemCoordinates.size()) {
        return;
    }
    size_t probeNum = nodeProbeDatas.size() + elemProbeDatas.size();
    if (probeNum > MAXIMUM_PROBE_TEXT_NUM && !showingMaximumProbeLog_) {
        qWarning(UI) << QStringLiteral(u"探针渲染数量上限%1，如果需要查看选取对象详细数据，请缩小选取范围。")
            .arg(MAXIMUM_PROBE_TEXT_NUM);
        showingMaximumProbeLog_ = true;
    }
    if (probeNum > MAXIMUM_PROBE_TEXT_NUM || probeNum == 0) {
        overlay->SetLabelTypeVisibility(ProbeLabelOverlay::LabelType::NODE, false);
        overlay->SetLabelTypeVisibility(ProbeLabelOverlay::LabelType::ELEM, false);
        return;
    }

    if (probeNum <= MAXIMUM_PROBE_TEXT_NUM) {
        showingMaximumProbeLog_ = false;
    }

    // 增量同步节点/单元标签(Min/Max 标签不受影响):已有标签位置保持不变,
    // 新选中的标签自动避让到最近空位,已取消选中的标签被移除(不触发全量重排)。
    bool renderVariable = (renderModel->GetColorType() != Base::VariableDataType::INVALID);
    {
        std::vector<Base::Vec3> anchors;
        std::vector<std::string> texts;
        std::vector<Base::ItemIdType> itemIds;
        std::vector<vtkIdType> pointOrCellIds;
        anchors.reserve(nodeProbeDatas.size());
        texts.reserve(nodeProbeDatas.size());
        itemIds.reserve(nodeProbeDatas.size());
        pointOrCellIds.reserve(nodeProbeDatas.size());
        for (size_t i = 0; i < nodeProbeDatas.size(); ++i) {
            anchors.push_back(nodeCoordinates[i]);
            texts.push_back(FillNodeProbeTextString(nodeProbeDatas[i], renderVariable));
            itemIds.push_back(nodeProbeDatas[i].itemInfo.itemId);
            pointOrCellIds.push_back(nodeProbeDatas[i].pointId);
        }
        overlay->SyncLabels(ProbeLabelOverlay::LabelType::NODE, anchors, texts, itemIds,
            pointOrCellIds, painter);
    }
    {
        std::vector<Base::Vec3> anchors;
        std::vector<std::string> texts;
        std::vector<Base::ItemIdType> itemIds;
        std::vector<vtkIdType> pointOrCellIds;
        anchors.reserve(elemProbeDatas.size());
        texts.reserve(elemProbeDatas.size());
        itemIds.reserve(elemProbeDatas.size());
        pointOrCellIds.reserve(elemProbeDatas.size());
        for (size_t i = 0; i < elemProbeDatas.size(); ++i) {
            anchors.push_back(elemCoordinates[i]);
            texts.push_back(FillElemProbeTextString(elemProbeDatas[i], renderVariable));
            itemIds.push_back(elemProbeDatas[i].itemInfo.itemId);
            pointOrCellIds.push_back(elemProbeDatas[i].cellId);
        }
        overlay->SyncLabels(ProbeLabelOverlay::LabelType::ELEM, anchors, texts, itemIds,
            pointOrCellIds, painter);
    }
    overlay->SetLabelTypeVisibility(ProbeLabelOverlay::LabelType::NODE, true);
    overlay->SetLabelTypeVisibility(ProbeLabelOverlay::LabelType::ELEM, true);
    overlay->SetVisibility(true);
}

void Painter::SimPostRenderer::UpdateExtremePointProbe(Base::SimPostMeshType type)
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    DomainModel& domain = GetOrCreateDomainModel(type);
    SimPostExtremePointPtr minimumPoint = domain.minimumProbe_;
    SimPostExtremePointPtr maximumPoint = domain.maximumProbe_;
    PTR_ASSERT_RETURN(minimumPoint);
    PTR_ASSERT_RETURN(maximumPoint);
    if (painter->GetPainterStatus().postViewState == Base::PostViewState::PRE_VIEW ||
        !showingAttributes_ || (!showingMinimumPoint_ && !showingMaximumPoint_)) {
        minimumPoint->SetVisibility(false);
        maximumPoint->SetVisibility(false);
        return;
    }

    ExtremeData extremeData = domain.renderModel_->GetExtremeData();
    if (std::isnan(extremeData.minValue_) || std::isnan(extremeData.maxValue_)) {
        minimumPoint->SetVisibility(false);
        maximumPoint->SetVisibility(false);
        return;
    }
    minimumPoint->SetId(extremeData.minId_);
    minimumPoint->SetPosition(extremeData.minPosition_);
    minimumPoint->SetValue(extremeData.minValue_);
    minimumPoint->Update();
    maximumPoint->SetId(extremeData.maxId_);
    maximumPoint->SetPosition(extremeData.maxPosition_);
    maximumPoint->SetValue(extremeData.maxValue_);
    maximumPoint->Update();
    minimumPoint->SetVisibility(showingMinimumPoint_);
    maximumPoint->SetVisibility(showingMaximumPoint_);
}

void Painter::SimPostRenderer::UpdateProbeDatas(Base::SimPostMeshType type)
{
    tf::Taskflow taskFlow;
    taskFlow.emplace([&] {
        UpdateProbeText(type);
        UpdateExtremePointProbe(type);
    });
    auto taskFuture = TaskScheduler::GetInstance()->RunAsync(std::move(taskFlow));
    RefreshNodeProbeData(type);
    RefreshElementProbeData(type);
    TaskScheduler::GetInstance()->Wait(std::move(taskFuture));
}

void Painter::SimPostRenderer::ShowAttributes()
{
    if (showingAttributes_) {
        return;
    }
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    showingAttributes_ = true;
    painter->AddRenderProp(scalarBarActor_);
    painter->AddOverlayRenderProp(informationText_->GetActor());
    scalarBarActor_->ShowAllWidgets();
}

void Painter::SimPostRenderer::HideAttributes()
{
    if (!showingAttributes_) {
        return;
    }
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    showingAttributes_ = false;
    painter->RemoveRenderProp(scalarBarActor_);
    painter->RemoveOverlayRenderProp(informationText_->GetActor());
    scalarBarActor_->HideAllWidgets();
}

void Painter::SimPostRenderer::ClearModelAttributes(Base::SimPostMeshType type)
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    renderModel->SetLookupTable(nullptr);
    renderModel->SetScalarMode(VTK_SCALAR_MODE_DEFAULT);
    renderModel->SelectColorArray(Base::VariableDataType::INVALID, "", -1);
    Notify(std::make_shared<SimPostVariableChangeEvent>(nullptr, VTK_SCALAR_MODE_DEFAULT, "",
        -1, Base::VariableDataType::INVALID));
}

void Painter::SimPostRenderer::ShowDataArray(Base::SimPostMeshType type,
    Base::VariableDataType dataType, const std::string& name, Base::VariableComponentType component,
    const std::string& title, const std::vector<std::pair<std::string, std::string>>& textInfos)
{
    Range range;
    switch (dataType) {
        case Base::VariableDataType::POINT:
            range = ShowPointDataArray(type, name, component, title);
            break;
        case Base::VariableDataType::CELL:
            range = ShowCellDataArray(type, name, component, title);
            break;
        case Base::VariableDataType::NONE_AVERAGE:
            range = ShowNonAverageDataArray(type, name, component, title);
            break;
        default:
            HideAttributes();
            ClearModelAttributes(type);
            return;
    }
    UpdateDisplayMode();
    UpdateInformationText(textInfos, range.min_.value_, range.max_.value_);
}

Painter::SimPostRenderer::Range Painter::SimPostRenderer::ShowPointDataArray(Base::SimPostMeshType type,
    const std::string& name, Base::VariableComponentType component, const std::string& title)
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    VariableRepresentation representation = GetVariableRepresentation(name, component,
        renderModel->GetPointDataComponentNum(name));
    if (representation.mode_ < 0) {
        qWarning() << QStringLiteral("SimPostRenderer point data %1 not legal.")
            .arg(QString(representation.arrayName_.c_str()));
        return {};
    }
    Range range;
    if (!renderModel->GeneratePointDataRange(representation.arrayName_, representation.component_, range)) {
        qWarning() << QStringLiteral("SimPostRenderer point data %1 not found.")
            .arg(QString(representation.arrayName_.c_str()));
        HideAttributes();
        ClearModelAttributes(type);
        return {};
    }
    ShowAttributes();
    renderModel->SetLookupTable(scalarBarActor_->GetLookupTable());
    scalarBarActor_->SetTitle(title.c_str());
    scalarBarActor_->SetVectorMode(representation.mode_);
    scalarBarActor_->SetVectorComponent(representation.component_);
    scalarBarActor_->UpdateScalarRangeValue(range.min_.value_, range.max_.value_);
    renderModel->SetScalarMode(VTK_SCALAR_MODE_USE_POINT_FIELD_DATA);
    renderModel->SelectColorArray(Base::VariableDataType::POINT,
        representation.arrayName_, representation.component_);
    Notify(std::make_shared<SimPostVariableChangeEvent>(scalarBarActor_->GetLookupTable(),
        VTK_SCALAR_MODE_USE_POINT_FIELD_DATA, representation.arrayName_, representation.component_,
        Base::VariableDataType::POINT));
    return range;
}

Painter::SimPostRenderer::Range Painter::SimPostRenderer::ShowCellDataArray(Base::SimPostMeshType type,
    const std::string& name, Base::VariableComponentType component, const std::string& title)
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    int componentNum = renderModel->GetCellDataComponentNum(name);
    VariableRepresentation representation = GetVariableRepresentation(name, component,
        renderModel->GetCellDataComponentNum(name));
    if (representation.mode_ < 0) {
        qWarning() << QStringLiteral("SimPostRenderer cell data %1 not legal.")
            .arg(QString(representation.arrayName_.c_str()));
        return {};
    }
    Range range;
    if (!renderModel->GenerateCellDataRange(representation.arrayName_, representation.component_, range)) {
        qWarning() << QStringLiteral("SimPostRenderer cell data %1 not found.")
            .arg(QString(representation.arrayName_.c_str()));
        HideAttributes();
        ClearModelAttributes(type);
        return {};
    }
    ShowAttributes();
    renderModel->SetLookupTable(scalarBarActor_->GetLookupTable());
    scalarBarActor_->SetTitle(title.c_str());
    scalarBarActor_->SetVectorMode(representation.mode_);
    scalarBarActor_->SetVectorComponent(representation.component_);
    scalarBarActor_->UpdateScalarRangeValue(range.min_.value_, range.max_.value_);
    renderModel->SetScalarMode(VTK_SCALAR_MODE_USE_CELL_FIELD_DATA);
    renderModel->SelectColorArray(Base::VariableDataType::CELL,
        representation.arrayName_, representation.component_);
    Notify(std::make_shared<SimPostVariableChangeEvent>(scalarBarActor_->GetLookupTable(),
        VTK_SCALAR_MODE_USE_CELL_FIELD_DATA, representation.arrayName_, representation.component_,
        Base::VariableDataType::CELL));
    return range;
}

Painter::SimPostRenderer::Range Painter::SimPostRenderer::ShowNonAverageDataArray(Base::SimPostMeshType type,
    const std::string& name, Base::VariableComponentType component, const std::string& title)
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(type).renderModel_;
    VariableRepresentation representation = GetVariableRepresentation(name, component,
        renderModel->GetNonAverageDataComponentNum(name));
    if (representation.mode_ < 0) {
        qWarning() << QStringLiteral("SimPostRenderer non average data %1 not legal.")
            .arg(QString(representation.arrayName_.c_str()));
        return {};
    }
    Range range;
    if (!renderModel->GenerateNonAverageDataRange(representation.arrayName_, representation.component_, range)) {
        qWarning() << QStringLiteral("SimPostRenderer non average data %1 not found.")
            .arg(QString(representation.arrayName_.c_str()));
        HideAttributes();
        ClearModelAttributes(type);
        return {};
    }
    ShowAttributes();
    renderModel->SetLookupTable(scalarBarActor_->GetLookupTable());
    scalarBarActor_->SetTitle(title.c_str());
    scalarBarActor_->SetVectorMode(representation.mode_);
    scalarBarActor_->SetVectorComponent(representation.component_);
    scalarBarActor_->UpdateScalarRangeValue(range.min_.value_, range.max_.value_);
    renderModel->SetScalarMode(VTK_SCALAR_MODE_USE_FIELD_DATA);
    renderModel->SelectColorArray(Base::VariableDataType::NONE_AVERAGE,
        representation.arrayName_, representation.component_);
    Notify(std::make_shared<SimPostVariableChangeEvent>(scalarBarActor_->GetLookupTable(),
        VTK_SCALAR_MODE_USE_FIELD_DATA, representation.arrayName_, representation.component_,
        Base::VariableDataType::NONE_AVERAGE));
    return range;
}

void Painter::SimPostRenderer::RenderModelDeformation(Base::SimPostMeshType type, const std::string& name)
{
    const DomainModel& domain = GetOrCreateDomainModel(type);
    bool enable = domain.deformationStatus_.type_ != Base::VariableDeformationCtrl::DeformationType::INVALID;
    ElemVisibilities newVisibilities;
    if (domain.renderModel_->SetPointsOffset(enable, name, domain.deformationStatus_.scale_, newVisibilities)) {
        Notify(std::make_shared<SimPostElemVisibilityEvent>(newVisibilities));
    }
    Notify(std::make_shared<SimPostVariableDeformationEvent>(enable, name, domain.deformationStatus_.scale_));
}

void Painter::SimPostRenderer::UpdateInformationText(
    const std::vector<std::pair<std::string, std::string>>& infomations, float minVal, float maxVal)
{
    PTR_ASSERT_RETURN(informationText_);
    informationText_->UpdateInformationText(infomations, minVal, maxVal);
    UpdateInformationPos();
}

Painter::SimPostRenderer::DomainModel& Painter::SimPostRenderer::GetOrCreateDomainModel(
    Base::SimPostMeshType type)
{
    auto iter = domainModels_.find(type);
    if (iter != domainModels_.end()) {
        return iter->second;
    }

    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter, domainModels_[type]);

    SimPostRenderModelPtr newModel = nullptr;
    // only simmesh needs selector now
    if (type == Base::SimPostMeshType::SIMMESH_MESH) {
        auto selector = std::make_shared<SimPostSelector>(painter, *this);
        newModel = std::make_shared<SimPostRenderModel>(painter, selector);
        InteractionHandlerPtr handler = painter->GetInteractor()->GetInteractionHandler();
        if (handler != nullptr) {
            handler->AddBoxSelector(selector);
        }
        painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::START_SCENE_PICK_EVENT,
            newModel.get(), &SimPostRenderModel::StartSceneSelection);
        painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::END_SCENE_PICK_EVENT,
            newModel.get(), &SimPostRenderModel::EndSceneSelection);
    } else {
        newModel = std::make_shared<SimPostRenderModel>(painter, nullptr);
    }

    newModel->SetInterpolateScalarsBeforeMapping(interpolateBeforeMapping_);
    ProbeLabelOverlayPtr newOverlay = std::make_shared<ProbeLabelOverlay>();
    SimPostExtremePointPtr minimumExtremePoint = std::make_shared<SimPostExtremePoint>();
    minimumExtremePoint->SetType(SimPostExtremePoint::MINIMUM);
    SimPostExtremePointPtr maximumExtremePoint = std::make_shared<SimPostExtremePoint>();
    maximumExtremePoint->SetType(SimPostExtremePoint::MAXIMUM);
    domainModels_[type].renderModel_ = newModel;
    domainModels_[type].probeLabelOverlay_ = newOverlay;
    domainModels_[type].minimumProbe_ = minimumExtremePoint;
    domainModels_[type].maximumProbe_ = maximumExtremePoint;
    UpdatePickupMode();
    UpdateDisplayMode();

    if (type == Base::SimPostMeshType::SIMMESH_MESH) {
        for (VTKCellHighlighterPtr highlighter : newModel->GetHilighters()) {
            painter->AddHighlighter(highlighter, false);
        }
        for (VTKCellHighlighterPtr highlighter : newModel->GetOverlayHilighters()) {
            painter->AddHighlighter(highlighter, true);
        }
    }

    for (VTKShapeRepresentationPtr shapeModel : newModel->GetShapeModels()) {
        painter->AddShapeRepresentation(shapeModel, false);
    }

    newOverlay->AddToPainter(painter);
    newOverlay->SetVisibility(false);

    minimumExtremePoint->SetVisibility(false);
    maximumExtremePoint->SetVisibility(false);
    minimumExtremePoint->AddToPainter(painter);
    maximumExtremePoint->AddToPainter(painter);

    return domainModels_[type];
}

void Painter::SimPostRenderer::OnWindowResize()
{
    UpdateInformationPos();
    // 防抖 300ms 后全量重算碰撞(不在此处直接调用 UpdateAllOverlayAnchors/TryRender,
    // 因为 WindowResizeEvent 可能从渲染管线中同步触发,直接 TryRender 会死锁)
    zoomDebounceTimer_.start();
}

Painter::SimPostRenderer::SimPostVariableChangeEvent::SimPostVariableChangeEvent(
    const vtkSmartPointer<vtkScalarsToColors> scalarsToColors, int scalarMode, const std::string& name,
    int component, Base::VariableDataType dataType)
    : lookupTable_(scalarsToColors), scalarMode_(scalarMode), name_(name), component_(component), dataType_(dataType)
{
}

Painter::SimPostRenderer::SimPostVariableChangeEvent::~SimPostVariableChangeEvent() = default;

Painter::RendererEvent::Type Painter::SimPostRenderer::SimPostVariableChangeEvent::GetType() const
{
    return RendererEvent::Type::SIM_POST_VARIABLE_CHANGE;
}

vtkSmartPointer<vtkScalarsToColors> Painter::SimPostRenderer::SimPostVariableChangeEvent::GetLookupTable() const
{
    return lookupTable_;
}

int Painter::SimPostRenderer::SimPostVariableChangeEvent::GetScalarMode() const
{
    return scalarMode_;
}

std::string Painter::SimPostRenderer::SimPostVariableChangeEvent::GetName() const
{
    return name_;
}

int Painter::SimPostRenderer::SimPostVariableChangeEvent::GetComponent() const
{
    return component_;
}

Base::VariableDataType Painter::SimPostRenderer::SimPostVariableChangeEvent::GetDataType() const
{
    return dataType_;
}

Painter::SimPostRenderer::SimPostVariableDeformationEvent::SimPostVariableDeformationEvent(
    bool enable, const std::string& arrayName, float scale)
    : enableDeformation_(enable), arrayName_(arrayName), scale_(scale)
{
}

Painter::SimPostRenderer::SimPostVariableDeformationEvent::~SimPostVariableDeformationEvent() = default;

Painter::RendererEvent::Type Painter::SimPostRenderer::SimPostVariableDeformationEvent::GetType() const
{
    return RendererEvent::Type::SIM_POST_VARIABLE_DEFORMATION;
}

bool Painter::SimPostRenderer::SimPostVariableDeformationEvent::GetEnable() const
{
    return enableDeformation_;
}

std::string Painter::SimPostRenderer::SimPostVariableDeformationEvent::GetArrayName() const
{
    return arrayName_;
}

float Painter::SimPostRenderer::SimPostVariableDeformationEvent::GetScale() const
{
    return scale_;
}

Painter::SimPostRenderer::SimPostElemVisibilityEvent::SimPostElemVisibilityEvent(
    const ElemVisibilities& newVisibilities)
    : newVisibilities_(newVisibilities)
{
}

Painter::SimPostRenderer::SimPostElemVisibilityEvent::~SimPostElemVisibilityEvent() = default;

Painter::RendererEvent::Type Painter::SimPostRenderer::SimPostElemVisibilityEvent::GetType() const
{
    return RendererEvent::Type::SIM_POST_ELEM_VISIBILITY_CHANGE;
}

using ElemVisibilities = Painter::SimPostRenderer::ElemVisibilities;
const ElemVisibilities& Painter::SimPostRenderer::SimPostElemVisibilityEvent::GetNewVisibilities() const
{
    return newVisibilities_;
}

void Painter::SimPostRenderer::UpdateInformationPos()
{
    PTR_ASSERT_RETURN(informationText_);
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    vtkVector2i widgetSize = painter->GetWidgetPixelSize();
    informationText_->UpdateInformationPos(widgetSize);
}

void Painter::SimPostRenderer::StartPostViewRender()
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    painter->GetInteractor()->InvokeInteractionEvent(VTKInteractorStyleSimMesh::PRESELECTION_CLEAR_EVENT);

    UpdatePickupMode();
    UpdateDisplayMode();
    for (const auto&[type, domain] : domainModels_) {
        UpdateProbeText(type);
        UpdateExtremePointProbe(type);
    }

    painter->TryResetCameraBeforeRender();
}

void Painter::SimPostRenderer::EndPostViewRender()
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    painter->GetInteractor()->InvokeInteractionEvent(VTKInteractorStyleSimMesh::PRESELECTION_CLEAR_EVENT);

    frameMergeTimer_.stop();
    zoomDebounceTimer_.stop();
    HideAttributes();
    ClearNodeSelection();
    ClearElemSelection();
    for (const auto&[type, domain] : domainModels_) {
        ClearModelAttributes(type);
        UpdateProbeDatas(type);
    }
    UpdatePickupMode();
    UpdateDisplayMode();

    painter->TryResetCameraBeforeRender();
}

void Painter::SimPostRenderer::OnStartRotateOrPan()
{
    frameMergeTimer_.start();
}

void Painter::SimPostRenderer::OnEndRotateOrPan()
{
    frameMergeTimer_.stop();
    RelayoutAllOverlays();
}

void Painter::SimPostRenderer::OnStartZoom()
{
    // 缩放开始时启动帧合并定时器，持续更新锚点和引出线
    frameMergeTimer_.start();
}

void Painter::SimPostRenderer::OnEndZoom()
{
    // 停止帧合并定时器
    frameMergeTimer_.stop();
    // 防抖 300ms 后全量重算碰撞(不在此处直接调用 UpdateAllOverlayAnchors/TryRender,
    // 因为 END_ZOOM_EVENT 可能从 OnStartRender→ResetViewerState 中同步触发,
    // 此时渲染管线 mutex 已锁,直接 TryRender 会死锁)
    zoomDebounceTimer_.start();
}

void Painter::SimPostRenderer::UpdateAllOverlayAnchors()
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    for (const auto&[type, domain] : domainModels_) {
        if (domain.probeLabelOverlay_ != nullptr) {
            domain.probeLabelOverlay_->UpdateAnchors(painter);
        }
    }
    TryRender(painter_);
}

void Painter::SimPostRenderer::RelayoutAllOverlays()
{
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    for (const auto&[type, domain] : domainModels_) {
        if (domain.probeLabelOverlay_ != nullptr) {
            domain.probeLabelOverlay_->RelayoutAfterViewChange(painter);
        }
    }
    TryRender(painter_);
}

bool Painter::SimPostRenderer::CheckAnimationRange(DomainModel& domain)
{
    AnimationStatus& animationStatus = domain.animationStatus_;
    animationStatus.minVal_ = FLT_MAX;
    animationStatus.maxVal_ = -FLT_MAX;
    SimPostRenderModelPtr renderModel = domain.renderModel_;
    for (const Base::AnimationInfos& frame : animationStatus.frames_) {
        VariableRepresentation representation = GetVariableRepresentation(frame.name, animationStatus.componentType_,
            renderModel->GetDataComponentNum(animationStatus.dataType_, frame.name));
        if (representation.mode_ < 0) {
            qWarning(UI) << QStringLiteral("SimPostRenderer animation data %1 not legal.")
                .arg(QString(frame.name.c_str()));
            return false;
        }
        Range range;
        if (!renderModel->GenerateDataRange(animationStatus.dataType_,
            representation.arrayName_, representation.component_, range)) {
            qWarning(UI) << QStringLiteral("SimPostRenderer animation data %1 not found.")
                .arg(QString(representation.arrayName_.c_str()));
            return false;
        }
        animationStatus.minVal_ = std::min(animationStatus.minVal_, range.min_.value_);
        animationStatus.maxVal_ = std::max(animationStatus.maxVal_, range.max_.value_);
    }
    return true;
}

void Painter::SimPostRenderer::SendNodeProbeDatas(
    Base::SimPostMeshType type, bool isSelect, const std::vector<SelectionData>& selectionDatas)
{
    if (!showingProbes_) {
        return;
    }

    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    std::vector<Base::SimPostNodeProbeData> nodeProbeDatas = GetNodeProbeDatas(type, selectionDatas);
    if (nodeProbeDatas.empty()) {
        return;
    }
    ROUTER(Route::SimPostOperationType::SHOW_NODES_PROBE)::Route(painter->GetProjectID(),
        GetOrCreateDomainModel(type).renderModel_->GetColorArrayName(), isSelect, nodeProbeDatas);
}

void Painter::SimPostRenderer::RefreshNodeProbeData(Base::SimPostMeshType type)
{
    if (!showingProbes_) {
        return;
    }

    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    const DomainModel& domain = GetOrCreateDomainModel(type);
    SimPostRenderModelPtr renderModel = domain.renderModel_;
    std::vector<Base::SimPostNodeProbeData> nodeProbeDatas =
        GetNodeProbeDatas(type, renderModel->GetSelectedNodes(REMOVED_CELL | HIDDEN_CELL));
    ROUTER(Route::SimPostOperationType::REFRESH_NODES_PROBE_DATA)::Route(painter->GetProjectID(),
        renderModel->GetColorArrayName(), nodeProbeDatas);
}

void Painter::SimPostRenderer::OnRefreshNodesProbeEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    // 响应 Python API refreshNodesData: 从当前选中节点获取最新 probeDatas 重新分发
    // RefreshNodeProbeData 内部会调用 ROUTER(REFRESH_NODES_PROBE_DATA), Service 同步 SendEvent
    // 会再次触发本处理器, 故用 thread_local guard 防死循环
    static thread_local bool inRefresh = false;
    if (inRefresh) {
        return;
    }
    // R7.7 RAII: 用 ThreadLocalBoolGuard 替代手写 inRefresh = true/false, 防止异常/early-return 导致标志泄漏。
    ThreadLocalBoolGuard guard(inRefresh);
    RefreshNodeProbeData(type);
}

void Painter::SimPostRenderer::SendElementProbeDatas(
    Base::SimPostMeshType type, bool isSelect, const std::vector<SelectionData> &selectionDatas)
{
    if (!showingProbes_) {
        return;
    }
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    std::vector<Base::SimPostElemProbeData> elementProbeDatas = GetElemProbeDatas(type, selectionDatas);
    if (elementProbeDatas.empty()) {
        return;
    }
    ROUTER(Route::SimPostOperationType::SHOW_ELEMENTS_PROBE)::Route(painter->GetProjectID(),
        GetOrCreateDomainModel(type).renderModel_->GetColorArrayName(), isSelect, elementProbeDatas);
}

void Painter::SimPostRenderer::RefreshElementProbeData(Base::SimPostMeshType type)
{
    if (!showingProbes_) {
        return;
    }
    VTKPainterPtr painter = painter_.lock();
    PTR_ASSERT_RETURN(painter);
    const DomainModel& domain = GetOrCreateDomainModel(type);
    SimPostRenderModelPtr renderModel = domain.renderModel_;
    std::vector<Base::SimPostElemProbeData> elementProbeDatas =
        GetElemProbeDatas(type, renderModel->GetSelectedElems(REMOVED_CELL | HIDDEN_CELL));
    ROUTER(Route::SimPostOperationType::REFRESH_ELEMENT_PROBE_DATA)::Route(painter->GetProjectID(),
        renderModel->GetColorArrayName(), elementProbeDatas);
}

void Painter::SimPostRenderer::OnRefreshElemsProbeEvent(Base::SimPostMeshType type, const Gui::PaintEvent* event)
{
    // 响应 Python API refreshElementsData: 从当前选中单元获取最新 probeDatas 重新分发
    // RefreshElementProbeData 内部会调用 ROUTER(REFRESH_ELEMENT_PROBE_DATA), Service 同步 SendEvent
    // 会再次触发本处理器, 故用 thread_local guard 防死循环
    static thread_local bool inRefresh = false;
    if (inRefresh) {
        return;
    }
    // R7.7 RAII: 用 ThreadLocalBoolGuard 替代手写 inRefresh = true/false, 防止异常/early-return 导致标志泄漏。
    ThreadLocalBoolGuard guard(inRefresh);
    RefreshElementProbeData(type);
}

void Painter::SimPostRenderer::ShowAllElems()
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH).renderModel_;
    ElemVisibilities newVisibilites;
    if (renderModel->ShowAllElems(newVisibilites)) {
        Notify(std::make_shared<SimPostElemVisibilityEvent>(newVisibilites));
    }
    if (!showingProbes_) {
        renderModel->ClearElemSelection();
    }
    TryRender(painter_);
}

void Painter::SimPostRenderer::HideSelectedElems()
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH).renderModel_;
    ElemVisibilities newVisibilites;
    if (renderModel->HideSelectedElems(newVisibilites)) {
        Notify(std::make_shared<SimPostElemVisibilityEvent>(newVisibilites));
    }
    if (!showingProbes_) {
        renderModel->ClearElemSelection();
    }
    TryRender(painter_);
}

void Painter::SimPostRenderer::HideUnselectedElems()
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH).renderModel_;
    ElemVisibilities newVisibilites;
    if (renderModel->HideUnselectedElems(newVisibilites)) {
        Notify(std::make_shared<SimPostElemVisibilityEvent>(newVisibilites));
    }
    if (!showingProbes_) {
        renderModel->ClearElemSelection();
    }
    TryRender(painter_);
}

void Painter::SimPostRenderer::ExpandVisibleElems()
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH).renderModel_;
    ElemVisibilities newVisibilites;
    if (renderModel->ExpandVisibleElems(newVisibilites)) {
        Notify(std::make_shared<SimPostElemVisibilityEvent>(newVisibilites));
    }
    if (!showingProbes_) {
        renderModel->ClearElemSelection();
    }
    TryRender(painter_);
}

void Painter::SimPostRenderer::ReverseVisibleElems()
{
    SimPostRenderModelPtr renderModel = GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH).renderModel_;
    ElemVisibilities newVisibilites;
    if (renderModel->ReverseVisibleElems(newVisibilites)) {
        Notify(std::make_shared<SimPostElemVisibilityEvent>(newVisibilites));
    }
    if (!showingProbes_) {
        renderModel->ClearElemSelection();
    }
    TryRender(painter_);
}

bool Painter::SimPostRenderer::HasHiddenElem()
{
    return GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH).renderModel_->HasHiddenElem();
}

bool Painter::SimPostRenderer::HasSelectedElem()
{
    return GetOrCreateDomainModel(Base::SimPostMeshType::SIMMESH_MESH).renderModel_->HasSelectedElem();
}

void Painter::SimPostRenderer::SetElemCutterPlanes(Base::SimPostMeshType type,
    vtkSmartPointer<vtkPlaneCollection> planes)
{
    ElemVisibilities newVisibilites;
    if (GetOrCreateDomainModel(type).renderModel_->SetElemCutterPlanes(planes, newVisibilites)) {
        Notify(std::make_shared<SimPostElemVisibilityEvent>(newVisibilites));
    }
}

std::vector<Painter::SimPostRenderer::SelectionData> Painter::SimPostRenderer::GetSelectedNodes(
    Base::SimPostMeshType type, CellRepresentationType skipValue)
{
    return GetOrCreateDomainModel(type).renderModel_->GetSelectedNodes(skipValue);
}

std::vector<Painter::SimPostRenderer::SelectionData> Painter::SimPostRenderer::GetSelectedElems(
    Base::SimPostMeshType type, CellRepresentationType skipValue)
{
    return GetOrCreateDomainModel(type).renderModel_->GetSelectedElems(skipValue);
}

std::vector<Base::Vec3> Painter::SimPostRenderer::GetNodesCoordinate(Base::SimPostMeshType type,
    const Base::ItemInfo& key, const std::vector<vtkIdType>& pointIds, bool withOffset, bool withScale)
{
    return GetOrCreateDomainModel(type).renderModel_->GetNodesCoordinate(key, pointIds, withOffset, withScale);
}

std::vector<Base::Vec3> Painter::SimPostRenderer::GetElemNodeCoordinates(Base::SimPostMeshType type,
    const Base::ItemInfo& key, vtkIdType cellId, bool withOffset, bool withScale)
{
    return GetOrCreateDomainModel(type).renderModel_->GetElemNodeCoordinates(key, cellId, withOffset, withScale);
}

vtkSmartPointer<vtkUnstructuredGrid> Painter::SimPostRenderer::GetItemUnstructuredGrid(
    Base::SimPostMeshType type, const Base::ItemInfo& key)
{
    // v3-opt53：方案B——转发到 SimPostRenderModel，供 SimPostSelector 体积统计访问渲染层 grid
    return GetOrCreateDomainModel(type).renderModel_->GetItemUnstructuredGrid(key);
}

double Painter::SimPostRenderer::GetPart2PartDistance(Base::SimPostMeshType type,
    const Base::ItemIdType part1Id, const Base::ItemIdType part2Id, std::vector<vtkIdType> &nodeIds)
{
    return GetOrCreateDomainModel(type).renderModel_->GetPart2PartDistance(part1Id, part2Id, nodeIds);
}


double Painter::SimPostRenderer::GetPoint2PartDistance(Base::SimPostMeshType type, const Base::PointInfo &point,
    const Base::ItemIdType &partId, vtkIdType &nodeId)
{
    return GetOrCreateDomainModel(type).renderModel_->GetPoint2PartDistance(point, partId, nodeId);
}