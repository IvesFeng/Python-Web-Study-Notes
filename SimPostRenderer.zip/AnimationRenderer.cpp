/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 */

#include <QLoggingCategory>
#include <QVariantMap>
#include "Source/Service/Common/Application/Application.h"
#include "Source/SystemFramework/EventDispatcher.h"


#include "PaintEvent.h"
#include "RendererTools.h"
#include "RenderManager.h"
#include "RenderProvider.h"
#include "AnimationRenderer.h"

Painter::AnimationRenderer::AnimationRenderer(VTKPainterPtr painter)
    : projectId_(painter != nullptr ? painter->GetProjectID() : -1)
{
    painter->GetRenderManager()->AddObserver(VTKRenderManager::PAINT_GL_EVENT,
        &frameCtrl_, &FrameCtrl::OnPaintGL);
    painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::BOXSELECT_START_EVENT,
        &frameCtrl_, &FrameCtrl::OnBoxSelectionStart);
    painter->GetInteractor()->AddObserver(VTKInteractorStyleSimMesh::BOXSELECT_END_EVENT,
        &frameCtrl_, &FrameCtrl::OnBoxSelectionEnd);
}

Painter::AnimationRenderer::~AnimationRenderer()
{
    StopAnimation(nullptr);
}

void Painter::AnimationRenderer::Init()
{
}

void Painter::AnimationRenderer::Render(const Gui::PaintEvent* event)
{
    if (event->GetType() == Base::Event::Type::SIMPOST_STOP_ANIMATION) {
        return OnStopAnimationEvent(event);
    }
    if (event->GetType() == Base::Event::Type::SIMPOST_ANIMATION_ACTIONS) {
        return OnAnimationActionsEvent(event);
    }
    if (event->GetType() == Base::Event::Type::SEND_ANIMATION_FRAME_RATE) {
        return OnAnimationFrameRateEvent(event);
    }
}

void Painter::AnimationRenderer::OnStopAnimationEvent(const Gui::PaintEvent* event)
{
    const Gui::SimStopAnimationEvent* animationEvent = dynamic_cast<const Gui::SimStopAnimationEvent*>(event);
    PTR_ASSERT_RETURN(animationEvent);
    bool needResetFrame = animationEvent->GetResetFrame();
    StopAnimation([this, needResetFrame]() {
        Notify(std::make_shared<AnimationEndEvent>(needResetFrame));
    });
}

void Painter::AnimationRenderer::OnAnimationActionsEvent(const Gui::PaintEvent* event)
{
    const Gui::SimAnimationActionsEvent* animationEvent
        = dynamic_cast<const Gui::SimAnimationActionsEvent*>(event);
    PTR_ASSERT_RETURN(animationEvent);
    Base::AnimationActionType actionType = animationEvent->GetActionType();
    switch (actionType) {
        case Base::AnimationActionType::PLAY:
            return PlayAnimation();
        case Base::AnimationActionType::PAUSE:
        case Base::AnimationActionType::FIRST_FRAME:
        case Base::AnimationActionType::LAST_FRAME:
            // Notify only after the playback thread stops advancing frames.
            return StopAnimation([this, actionType]() {
                Notify(std::make_shared<AnimationPauseEvent>(actionType));
            });
        default:
            break;
    }
}

void Painter::AnimationRenderer::OnAnimationFrameRateEvent(const Gui::PaintEvent* event)
{
    const Gui::SendAnimationFrameRateEvent* animationEvent
        = dynamic_cast<const Gui::SendAnimationFrameRateEvent*>(event);
    PTR_ASSERT_RETURN(animationEvent);

    double frameRate = animationEvent->GetFrameRate();
    if (SetFrameRate(frameRate)) {
        QVariantMap data;
        data.insert("projectId", QVariant::fromValue(projectId_));
        data.insert("fps", static_cast<int>(frameRate));
        App::GetEventDispatcher().SubmitEvent("simpost.animation.frameRateChanged", data);
    }
}

void Painter::AnimationRenderer::PlayAnimation()
{
    {
        std::lock_guard<std::mutex> lock(animationCtrl_.mtx_);
        if (animationCtrl_.play_) {
            qWarning() << "animation is already playing.";
            return;
        }
        // Mark the request before launching the worker, so an immediate pause is not lost.
        animationCtrl_.play_ = true;
        animationCtrl_.stop_ = false;
        frameCtrl_.Reset();
    }
    std::thread(&AnimationRenderer::AnimationThread,
        GetConcreteRenderer<AnimationRenderer>(GetAllRenderers()).lock()).detach();
}

void Painter::AnimationRenderer::StopAnimation(const std::function<void(void)>& callback)
{
    std::unique_lock<std::mutex> lock(animationCtrl_.mtx_);
    if (!animationCtrl_.play_) {
        lock.unlock();
        // Callbacks may prepare frames and re-enter StopAnimation.
        if (callback != nullptr) callback();
        return;
    }
    animationCtrl_.animationCallback_ = callback;
    animationCtrl_.stop_ = true;
    animationCtrl_.playCV_.notify_one();
    frameCtrl_.CancelWait();
}

double Painter::AnimationRenderer::GetFrameRate()
{
    std::lock_guard<std::mutex> lock(animationCtrl_.mtx_);
    return animationCtrl_.frameRate_;
}

bool Painter::AnimationRenderer::SetFrameRate(double frameRate)
{
    if (frameRate <= DBL_EPSILON || frameRate > 1000.) { // 1000. : maximum frame rate
        qWarning() << QStringLiteral(u"frame rate can not be set to %1.").arg(frameRate);
        return false;
    }

    std::lock_guard<std::mutex> lock(animationCtrl_.mtx_);
    animationCtrl_.frameRate_ = frameRate;
    return true;
}

void Painter::AnimationRenderer::OnAnimationStart(Base::ProjectIDType projectId)
{
    RenderManager::GetInstance().ProcessInProject(projectId, [](RenderProvider& provider) {
        VTKPainterPtr painter = provider.GetPainter();
        PTR_ASSERT_RETURN(painter);
        auto renderer = GetConcreteRenderer<AnimationRenderer>(provider.GetAllRenderer()).lock();
        PTR_ASSERT_RETURN(renderer);
        renderer->Notify(std::make_shared<AnimationStartEvent>());
        painter->GetInteractor()->SetShapePickEnable(false);
        painter->GetInteractor()->ChangeMouseKeyStatus().enableBoxSelection = false;
        painter->TryRender();
        renderer->frameCtrl_.OnTicked();
    });
}

void Painter::AnimationRenderer::OnAnimationEnd(Base::ProjectIDType projectId)
{
    RenderManager::GetInstance().ProcessInProject(projectId, [](RenderProvider& provider) {
        VTKPainterPtr painter = provider.GetPainter();
        PTR_ASSERT_RETURN(painter);
        auto renderer = GetConcreteRenderer<AnimationRenderer>(provider.GetAllRenderer()).lock();
        PTR_ASSERT_RETURN(renderer);
        painter->GetInteractor()->SetShapePickEnable(true);
        painter->GetInteractor()->ChangeMouseKeyStatus().enableBoxSelection = true;
        std::function<void(void)> callback;
        {
            std::lock_guard<std::mutex> lock(renderer->animationCtrl_.mtx_);
            callback = std::move(renderer->animationCtrl_.animationCallback_);
            renderer->animationCtrl_.animationCallback_ = nullptr;
            renderer->animationCtrl_.play_ = false;
            renderer->animationCtrl_.stop_ = false;
        }
        // Publish the stopped state before running a callback that may prepare/restart animation.
        if (callback != nullptr) {
            callback();
            painter->TryRender();
        }
    });
}

void Painter::AnimationRenderer::OnAnimationTick(Base::ProjectIDType projectId)
{
    RenderManager::GetInstance().ProcessInProject(projectId, [](RenderProvider& provider) {
        VTKPainterPtr painter = provider.GetPainter();
        PTR_ASSERT_RETURN(painter);
        auto renderer = GetConcreteRenderer<AnimationRenderer>(provider.GetAllRenderer()).lock();
        PTR_ASSERT_RETURN(renderer);
        renderer->Notify(std::make_shared<AnimationTickEvent>());
        painter->TryRender();
        renderer->frameCtrl_.OnTicked();
    });
}

void Painter::AnimationRenderer::AnimationThread(std::shared_ptr<AnimationRenderer> renderer)
{
    PTR_ASSERT_RETURN(renderer);
    // 不要在动画线程里持有 painter 强引用：工程关闭时动画线程可能成为
    // VTKPainter 的最后一个持有者，导致 VTKPainter/VTKPropTrashBin 的
    // QTimer 在动画线程析构（Qt 报 "Timers cannot be stopped from another
    // thread"），残留 timer 事件回到主线程后回调已析构对象。
    Base::ProjectIDType projectId = renderer->projectId_;
    if (projectId < 0) {
        return;
    }
    AnimationCtrl& animationCtrl = renderer->animationCtrl_;
    OnAnimationStart(projectId);
    auto nextTickTime = std::chrono::steady_clock::now();
    while (true) {
        {
            std::unique_lock<std::mutex> lock(animationCtrl.mtx_);
            animationCtrl.playCV_.wait_until(lock, nextTickTime, [&]() {
                return animationCtrl.stop_;
            });

            if (animationCtrl.stop_) {
                break;
            }

            double frameInterval = 1000000. / animationCtrl.frameRate_; // 1000000. : frame interval with microseconds
            auto tickTime = std::chrono::steady_clock::now();
            nextTickTime = tickTime + std::chrono::microseconds(static_cast<int64_t>(frameInterval));
        }

        if (!renderer->frameCtrl_.WaitUntilReady()) {
            break;
        }
        OnAnimationTick(projectId);
    }
    OnAnimationEnd(projectId);
}

Painter::AnimationRenderer::AnimationStartEvent::AnimationStartEvent() = default;

Painter::AnimationRenderer::AnimationStartEvent::~AnimationStartEvent() = default;

Painter::RendererEvent::Type Painter::AnimationRenderer::AnimationStartEvent::GetType() const
{
    return RendererEvent::Type::ANIMATION_START;
}

Painter::AnimationRenderer::AnimationEndEvent::AnimationEndEvent(bool resetFrame)
    : resetFrame_(resetFrame)
{
}

Painter::AnimationRenderer::AnimationEndEvent::~AnimationEndEvent() = default;

Painter::RendererEvent::Type Painter::AnimationRenderer::AnimationEndEvent::GetType() const
{
    return RendererEvent::Type::ANIMATION_END;
}

bool Painter::AnimationRenderer::AnimationEndEvent::NeedResetFrame() const
{
    return resetFrame_;
}

Painter::AnimationRenderer::AnimationPauseEvent::AnimationPauseEvent(Base::AnimationActionType action)
    : action_(action)
{
}

Base::AnimationActionType Painter::AnimationRenderer::AnimationPauseEvent::GetAction() const
{
    return action_;
}

Painter::AnimationRenderer::AnimationPauseEvent::~AnimationPauseEvent() = default;

Painter::RendererEvent::Type Painter::AnimationRenderer::AnimationPauseEvent::GetType() const
{
    return RendererEvent::Type::ANIMATION_PAUSE;
}

Painter::AnimationRenderer::AnimationTickEvent::AnimationTickEvent() = default;

Painter::AnimationRenderer::AnimationTickEvent::~AnimationTickEvent() = default;

Painter::RendererEvent::Type Painter::AnimationRenderer::AnimationTickEvent::GetType() const
{
    return RendererEvent::Type::ANIMATION_TICK;
}

bool Painter::AnimationRenderer::FrameCtrl::WaitUntilReady()
{
    std::unique_lock<std::mutex> lock(tickMtx_);
    tickCV_.wait(lock, [this] {
        return cancelled_ || (lastTickOver_ && !onBoxSelection_);
    });
    return !cancelled_;
}

void Painter::AnimationRenderer::FrameCtrl::Reset()
{
    std::lock_guard<std::mutex> lock(tickMtx_);
    cancelled_ = false;
    lastTickOver_ = true;
}

void Painter::AnimationRenderer::FrameCtrl::CancelWait()
{
    std::lock_guard<std::mutex> lock(tickMtx_);
    cancelled_ = true;
    tickCV_.notify_one();
}

void Painter::AnimationRenderer::FrameCtrl::OnTicked()
{
    std::unique_lock<std::mutex> lock(tickMtx_);
    lastTickOver_ = false;
}

void Painter::AnimationRenderer::FrameCtrl::OnPaintGL()
{
    std::unique_lock<std::mutex> lock(tickMtx_);
    lastTickOver_ = true;
    tickCV_.notify_one();
}

void Painter::AnimationRenderer::FrameCtrl::OnBoxSelectionStart()
{
    std::unique_lock<std::mutex> lock(tickMtx_);
    onBoxSelection_ = true;
}

void Painter::AnimationRenderer::FrameCtrl::OnBoxSelectionEnd()
{
    std::unique_lock<std::mutex> lock(tickMtx_);
    onBoxSelection_ = false;
    tickCV_.notify_one();
}
