/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
 */

#ifndef PAINTER_ANIMATION_RENDERER_H
#define PAINTER_ANIMATION_RENDERER_H

#include "Obsever.h"
#include "BaseSimPost.h"

#include "IRenderer.h"
#include "RendererEvent.h"
#include "RendererRegister.h"

namespace Painter {
    class AnimationRenderer : public IRenderer, private RendererRegister<AnimationRenderer>,
        public Base::Subject<RendererEventPtr> {
    public:
        class AnimationStartEvent : public RendererEvent {
        public:
            AnimationStartEvent();
            ~AnimationStartEvent() override;
            Type GetType() const override;
        };

        class AnimationEndEvent : public RendererEvent {
        public:
            explicit AnimationEndEvent(bool resetFrame);
            ~AnimationEndEvent() override;
            Type GetType() const override;
            bool NeedResetFrame() const;
        private:
            bool resetFrame_{ false };
        };

        class AnimationPauseEvent : public RendererEvent {
        public:
            explicit AnimationPauseEvent(Base::AnimationActionType action = Base::AnimationActionType::PAUSE);
            ~AnimationPauseEvent() override;
            Type GetType() const override;
            Base::AnimationActionType GetAction() const;
        private:
            Base::AnimationActionType action_;
        };

        class AnimationTickEvent : public RendererEvent {
        public:
            AnimationTickEvent();
            ~AnimationTickEvent() override;
            Type GetType() const override;
        };

        explicit AnimationRenderer(VTKPainterPtr painter);
        ~AnimationRenderer() override;
        void Init() override;
        double GetFrameRate();

    private:
        void Render(const Gui::PaintEvent* event) override;
        void OnStopAnimationEvent(const Gui::PaintEvent* event);
        void OnAnimationActionsEvent(const Gui::PaintEvent* event);
        void OnAnimationFrameRateEvent(const Gui::PaintEvent* event);

        void PlayAnimation();
        void StopAnimation(const std::function<void(void)>& callback);
        bool SetFrameRate(double frameRate);

        static void OnAnimationStart(Base::ProjectIDType projectId);
        static void OnAnimationEnd(Base::ProjectIDType projectId);
        static void OnAnimationTick(Base::ProjectIDType projectId);
        static void AnimationThread(std::shared_ptr<AnimationRenderer> renderer);

    private:
        struct AnimationCtrl {
            bool play_{ false };
            bool stop_{ false };
            double frameRate_{ 10 };
            std::mutex mtx_;
            std::condition_variable playCV_;
            std::function<void(void)> animationCallback_{ nullptr };
        };

        class FrameCtrl {
        public:
            bool WaitUntilReady();
            void Reset();
            void CancelWait();
            void OnTicked();
            void OnPaintGL();
            void OnBoxSelectionStart();
            void OnBoxSelectionEnd();

        private:
            bool lastTickOver_{ true };
            bool cancelled_{ false };
            bool onBoxSelection_{ false };
            std::condition_variable tickCV_;
            std::mutex tickMtx_;
        };

        Base::ProjectIDType projectId_{ -1 };
        FrameCtrl frameCtrl_;
        AnimationCtrl animationCtrl_;
    };
}

#endif