/*
* Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
*/
#include "SimAnimationWidget.h"
#include <QWidget>
#include <QSignalBlocker>
#include <QVariantMap>
#include "AnimationRenderer.h"
#include "RendererTools.h"
#include "RenderProvider.h"
#include "Source/SystemFramework/EventDispatcher.h"
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QLabel>
#include <qpushbutton.h>
#include <qslider.h>
#include <qcombobox.h>
#include <QToolButton>
#include "GuiBaseGlobal.h"
#include "ProjectOperation.h"
#include "SimPostOperation.h"
#include "PaintDevice.h"
#include "RenderManager.h"
#include "ImageFactory.h"
#include "CommandManager.h"
#include "ToolButton.h"
#include <qscopeguard.h>
#include "NativeMachineController.h"
#include "MemoryWarningDialog.h"
using namespace Route;

namespace {
    const QString SUB_STEP_FREQ = "Frequency";
    const QString SUB_STEP_TIME = "Time";
    const QString SUB_STEP_ITERATION = "Iteration";
    const int WIDTH = 270; /* 270: 设计宽度 */
    const int COMBOBOX_WIDTH = 130; /* 130: QComboBox控件宽度 */
    const int BTN_FRAME_SIZE = 20;
    const int BTN_SIZE = 18;
    const int N_FRAMES = 1;
    const int X_POS = 200;
    const int Y_POS = 600;
    const QString MaxStyle = (
        "QCheckBox{color: rgb(216, 19, 19);"
        "font-family: 微软雅黑;"
        "font-size: 12px;"
        "font-weight: 700;"
        "line-height: 16.8px;"
        "letter-spacing: 0px;"
        "}");

    const QString QCOMBOBOX_STYLE = (
        "QComboBox {"
        "border: 1px solid rgba(152, 152, 152, 0.26);"
        "width: 80px;"
        "}"
        "QComboBox:editable {"
        "background-color: white;"
        "}"
        "QComboBox:!editable {"
        "background-color: white;"
        "}"
        "QComboBox:editable:on {"
        "background-color: white;"
        "}");
    const QString PROGRESS_STYLE = (
        "QSlider::groove:horizontal{"
        "border : 1px solid #FFFFFF;"
        "background : #FFFFFF;"
        "height : 2px;"
        "border-radius: 1px;"
        "padding-left:0px;"
        "padding-right:0px;"
        "}"
        "QSlider::sub-page:horizontal{"
        "background : #474747;"
        "border : 1px solid #474747;"
        "height : 2px;"
        "border-radius: 2px;"
        "}"
        "QSlider::add-page:horizontal{"
        "background : #FFFFFF;"
        "border : 0px solid #FFFFFF;"
        "height : 2px;"
        "border-radius: 2px;"
        "}"
        "QSlider::handle:horizontal{"
        "background : qradialgradient(spread : pad, cx : 0.5, cy : 0.5, radius : 0.5, fx : 0.5, fy : 0.5,"
        "stop : 0.6 #FFFFFF,stop:0.98409 rgba(217, 217, 217, 217));"
        "width : 15px;"
        "margin-top: -6px;"
        "margin-bottom: -6px;"
        "border-radius: 5px;"
        "}"
        );
    const QString FRAMES_STYLE = (
        "QSlider::handle:horizontal {"
        "background: #474747;"
        "}"
        );
}

namespace Gui {
    void SetBtnStyle(QPushButton *btn, const QString &path, const QString &tips);

    struct SimAnimationWidgetPrivateData {
        QHBoxLayout *hLayoutPlay{ nullptr };
        QHBoxLayout *hLayoutSlider{ nullptr };
        QHBoxLayout *hLayoutFrameRate{ nullptr };

        QPushButton *jumpFirstFrame{ nullptr };
        QPushButton *jumpForwardNFrames{ nullptr };
        QPushButton *playPauseBtn{ nullptr };
        bool isPlay = false;
        QPushButton *stopBtn{ nullptr };
        QPushButton *jumpBackwardNFrames{ nullptr };
        QPushButton *jumpLastFrame{ nullptr };
        QToolButton *exportBtn{ nullptr };
        QLabel *exportLabel{ nullptr };

        QSlider *progress{ nullptr };
        QComboBox *pointInTime{ nullptr };
        QSlider *frameRate{ nullptr };
        QLabel *frameLabel{ nullptr };
        bool isStop = true;
        Base::ProjectIDType currId{ -1 };
        bool isUpdateProgress{ true };
        bool isAddFieldData{ false };
    };

    SimAnimationWidget *SimAnimationWidget::GetInstance()
    {
        if (instance == nullptr) {
            PaintDevice *dev = Painter::RenderManager::GetInstance().PaintDevice();
            instance = new SimAnimationWidget(dev);
        }
        return instance;
    }
    SimAnimationWidget *SimAnimationWidget::instance = nullptr;

    SimAnimationWidget::SimAnimationWidget(QWidget *parent)
    {
        d.reset(new SimAnimationWidgetPrivateData());
        CreateItems();
        App::GetEventDispatcher().ConnectToEvent("simpost.animation.frameRateChanged", this,
            [this](const QVariant &value) {
                const QVariantMap data = value.toMap();
                const auto projectId = ROUTER_NO_RECORD(ProjectOperationType::GET_CURRENT_PROJECT_ID)
                    ::Route().GetData<Base::ProjectIDType>();
                if (data.value("projectId").value<Base::ProjectIDType>() == projectId) {
                    SetFrameRate(data.value("fps").toInt());
                }
            }, Qt::AutoConnection);
        App::GetEventDispatcher().ConnectToEvent("simpost.animation.frameJumped", this,
            [this](const QVariant &value) {
                const QVariantMap data = value.toMap();
                const auto projectId = ROUTER_NO_RECORD(ProjectOperationType::GET_CURRENT_PROJECT_ID)
                    ::Route().GetData<Base::ProjectIDType>();
                if (data.value("projectId").value<Base::ProjectIDType>() != projectId) return;
                d->isPlay = false;
                d->isStop = false;
                d->isUpdateProgress = true;
                SetBtnStyle(d->playPauseBtn, "AnimationPauseBtn.svg", QStringLiteral(u"播放"));
                SetProbeStatus(true);
                SlotPlayOrPause(true);
                d->stopBtn->setEnabled(true);
                d->pointInTime->setCurrentIndex(data.value("index").toInt());
            }, Qt::AutoConnection);
        SyncFrameRate();
    }

    SimAnimationWidget::~SimAnimationWidget()
    {
    }

    void SimAnimationWidget::CheckIsShowWaitLab(Base::ProjectIDType projectId,
        QLabel *waitStatusLab)
    {
        QPixmap pixmap(GetImagePath("probeLoadingDatas"));
        waitStatusLab->setWindowFlags(Qt::FramelessWindowHint);
        waitStatusLab->setAlignment(Qt::AlignHCenter | Qt::AlignVCenter);
        waitStatusLab->setWindowModality(Qt::WindowModality::WindowModal);
        waitStatusLab->setPixmap(pixmap);
        SetStyleSheet(waitStatusLab, "QLabel{background-color: grey;}");
        waitStatusLab->show();
        QPoint globalPos = parentWidget()->mapToGlobal(QPoint(0, 0));
        waitStatusLab->move(globalPos.x() + X_POS, globalPos.y() + Y_POS);
        QCoreApplication::processEvents();
    }

    void GetStepNodeItemId(const QString &stepName, Base::ItemIdType &stepItemId)
    {
        Base::ProjectIDType projectId =
            ROUTER(Route::ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        Base::Result result = ROUTER(Route::SimPostOperationType::GET_ALL_FIELD_ITEMS)::Route(projectId);
        const Base::BaseSimPostTree simPostTree = result.GetData<Base::BaseSimPostTree>();
        for (const Base::FieldOutputItemPtr simPostPtr : simPostTree) {
            IS_NULL_SHARED_PTR_CONTINUE(simPostPtr);
            bool isParentStep =
                (simPostPtr->step == stepName) && simPostPtr->value.isEmpty() && simPostPtr->var.isEmpty();
            if (isParentStep) {
                stepItemId = simPostPtr->itemId;
                return;
            }
        }
    }

    void SetAnimationInfos(std::vector<Base::AnimationInfos> &allInfos, Base::ItemIdType itemId, double val)
    {
        Base::AnimationInfos tmpInfos;
        tmpInfos.treeItemId = itemId;
        tmpInfos.timeOrFreq = val;
        allInfos.push_back(tmpInfos);
    }

    Base::ItemIdType CheckNameIsExist(Base::ProjectIDType projectId,
        Base::ItemIdType stepItemId, const QString &baseName)
    {
        Base::Result result = ROUTER(Route::SimPostOperationType::GET_ALL_FIELD_ITEMS)::Route(projectId);
        const Base::BaseSimPostTree simPostTree = result.GetData<Base::BaseSimPostTree>();
        for (const Base::FieldOutputItemPtr simPostPtr : simPostTree) {
            if (!simPostPtr.isNull() && simPostPtr->parentId == stepItemId && simPostPtr->name == baseName) {
                return simPostPtr->itemId;
            }
        }
        return -1;
    }

    Base::ItemIdType CheckParaDatas(QString &baseName, const QString &timePoint, Base::ItemIdType stepItemId)
    {
        int pos = baseName.lastIndexOf('_');
        if (pos == -1) {
            return -1;
        }
        baseName = baseName.left(pos);
        baseName += "_" + timePoint;

        Base::ProjectIDType projectId =
            ROUTER(Route::ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        return CheckNameIsExist(projectId, stepItemId, baseName);
    }

    void SendVariableDeformation()
    {
        Base::ProjectIDType projectId =
            ROUTER(Route::ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        Base::VariableDeformationCtrl variableDeformationCtrl;
        ROUTER(Route::SimPostOperationType::GET_VARIABLE_DEFORMATION)::Route(projectId, variableDeformationCtrl);
        // 自动联动同步变形状态到新动画云图(GET→SET同值),属于衍生副作用,不应录制。
        // 用 ROUTER_NO_RECORD 避免污染宏脚本;用户主动在变形表修改仍用 ROUTER 录制。
        ROUTER_NO_RECORD(Route::SimPostOperationType::SET_VARIABLE_DEFORMATION)::Route(
            projectId, variableDeformationCtrl);
    }

    Base::SimPostItemPtr GetCurrentPtr(Base::ProjectIDType projectId)
    {
        Base::ItemIdType renderedId =
            ROUTER(SimPostOperationType::GET_CURRENT_RENDERED_FIELD)::Route(projectId).GetData<int>();
        return ROUTER(Route::SimPostOperationType::GET_SIMPOST_ITEM_BY_ID)::Route(
            projectId, renderedId).GetData<Base::SimPostItemPtr>();
    }

    int SimAnimationWidget::CreateNewFieldDatas(const Base::FieldOutputItemPtr simPostPtr,
        Base::ItemIdType stepItemId, const QString &baseName, const QString &timeFreq)
    {
        IS_NULL_PTR_RETURN(simPostPtr, -1);
        Base::ProjectIDType projectId =
            ROUTER(Route::ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        Base::FieldOutputItemPtr varNodePtr = Base::FieldOutputItemPtr::create(*simPostPtr);
        varNodePtr->itemId = ROUTER(SimPostOperationType::GET_NEW_SIMPOST_ITEM_ID)::Route(projectId).GetData<int>();
        varNodePtr->parentId = stepItemId;
        varNodePtr->name = baseName;
        varNodePtr->attachVarList.clear();
        varNodePtr->value = timeFreq; // 每一个timeFreq创建
        varNodePtr->isAddField = d->isAddFieldData; // 标记动画数据
        Base::Result res = ROUTER(SimPostOperationType::CREATE_FIELD_ITEMS_BY_TIMES)::Route(projectId, varNodePtr);
        if (res.code == Base::ResponseCode::FAILED) {
            qCritical(UI) << tr("%1 Create failed, please check the file data.").arg(varNodePtr->name);
            return -1;
        }
        return varNodePtr->itemId;
    }

    bool SimAnimationWidget::CheckLoadH5DatasIsOOM(Base::ProjectIDType projectId,
        double retSize, const QVector<Base::ItemIdType> &createItemIds)
    {
        auto machineMemory = App::NativeMachineController::GetInstance()->GetMachineMemory();
        double availableMemory = 0.0;
        if (machineMemory->availPhys > 0) {
            availableMemory = machineMemory->availPhys * 0.000000001; // 0.000000001 字节转 GB;
        }
        if (availableMemory <= 0.0) {
            return false;
        }
        // 如果可用内存小于阈值，弹窗提示用户选择
        if (retSize > availableMemory) {
            MemoryWarningDialog dlg(retSize, availableMemory, nullptr);
            dlg.SetDialogParam();
            dlg.exec();
            MemoryWarningResult r = dlg.result();
            switch (r) {
                case MemoryWarningResult::ContinueImport:
                    return false;
                case MemoryWarningResult::Cancel:
                    ROUTER(SimPostOperationType::DELETE_ITEMS_AFTER_STOP)::Route(projectId,
                        createItemIds).GetData<Base::FieldOutputItemPtr>();
                    return true;
                default:
                    ROUTER(SimPostOperationType::DELETE_ITEMS_AFTER_STOP)::Route(projectId,
                        createItemIds).GetData<Base::FieldOutputItemPtr>();
                    return true;
                }
        }
        return false;
    }

    bool SimAnimationWidget::CreateAnimationByTimes(bool isSendDefor)
    {
        // Read the renderer's rate; preparing frames must not resend a stale UI value.
        SyncFrameRate();
        Base::ProjectIDType projectId =
            ROUTER(Route::ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        QLabel *waitStatusLab = new QLabel();
        auto cleanup = qScopeGuard([&waitStatusLab]() {
            delete waitStatusLab;
            waitStatusLab = nullptr;
        });
        CheckIsShowWaitLab(projectId, waitStatusLab);
        const Base::FieldOutputItemPtr simPostPtr = GetCurrentPtr(projectId).dynamicCast<Base::FieldOutputItem>();
        if (simPostPtr.isNull()) {
            qCritical(UI) << tr("Create failed. Please create the current data cloud map.");
            return false;
        }
        // 内存预估与弹窗确认（UI 交互保留在 widget）
        double retSize = ROUTER(SimPostOperationType::GET_H5SOURCE_DATAS_SIZE)::Route(projectId,
            simPostPtr).GetData<double>();
        if (CheckLoadH5DatasIsOOM(projectId,
            qMin(retSize * simPostPtr->timesOrFreqs.size(), 20.0), {})) {
            return false;
        }
        // 复用 service 层统一动画准备函数（PREPARE_ANIMATION_FRAMES）
        // 内部完成：前置 STOP_ANIMATION(reset=true) → 枚举时间点 → 创建/复用帧 → SEND_ANIMATION_NAMES
        // isSendDefor=true 表示由用户主动播放触发，需要录制 createAnimation+play 序列；
        // isSendDefor=false 为进度条/导出等衍生操作，不录制
        Base::AnimationFrameSource frameSource = d->isAddFieldData
            ? Base::AnimationFrameSource::BY_SECTION
            : Base::AnimationFrameSource::BY_TIMES;
        Base::AnimationPrepareResult prepResult =
            (isSendDefor
                ? ROUTER(SimPostOperationType::PREPARE_ANIMATION_FRAMES)
                    ::Route(projectId, simPostPtr->itemId, frameSource)
                : ROUTER_NO_RECORD(SimPostOperationType::PREPARE_ANIMATION_FRAMES)
                    ::Route(projectId, simPostPtr->itemId, frameSource)
            );
        if (!prepResult.success) {
            qCritical(UI) << tr("Create failed. %1").arg(prepResult.errMsg);
            return false;
        }
        return true;
    }

    void SetBtnStyle(QPushButton *btn, const QString &path, const QString &tips)
    {
        IS_NULL_PTR_RETURN(btn);
        btn->setFixedSize(BTN_FRAME_SIZE, BTN_FRAME_SIZE);
        QIcon icon = GetImageIcon(path);
        btn->setIcon(icon);
        btn->setIconSize(QSize(BTN_SIZE, BTN_SIZE));
        btn->setToolTip(tips);
    }

    void SimAnimationWidget::SetProbeStatus(bool isShow)
    {
        Base::ProjectIDType proId =
            ROUTER(Route::ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        QVector<QWidget*> buttons = Gui::CommandManager::Instance()->GetButtonByCmdName("ViewProbe");
        if (buttons.empty() || buttons[0] == nullptr) { // 仅获取第一个，如果获取失败，则退出
            return;
        }
        QWidget *widget = buttons[0];
        ToolButton *button = dynamic_cast<ToolButton*>(widget);
        IS_NULL_PTR_RETURN(button);
        if (!isShow && button->GetChecked()) {
            QCoreApplication::processEvents();
            button->Click();
            ROUTER(SimPostOperationType::SET_SHOW_NODES_PROBE_STATUS)::Route(proId, isShow);
        }
        button->setEnabled(isShow);
    }

    void SimAnimationWidget::InitPlayPauseItems()
    {
        d->playPauseBtn = new QPushButton();
        SetBtnStyle(d->playPauseBtn, "AnimationPauseBtn.svg", QStringLiteral(u"播放"));
        d->isPlay = false;
        connect(d->playPauseBtn, &QPushButton::clicked, [this]() {
            Base::ProjectIDType proId =
                ROUTER(ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
            d->currId = proId;
            if (d->isPlay) {
                SetProbeStatus(true);
                d->isPlay = false;
                d->isStop = false;
                SetBtnStyle(d->playPauseBtn, "AnimationPauseBtn.svg", QStringLiteral(u"播放"));
                SlotPlayOrPause(true);
                ROUTER(SimPostOperationType::SET_ANIMATION_ACTIONS)::Route(proId, Base::AnimationActionType::PAUSE);
            } else {
                if (d->isStop &&
                    ROUTER(SimPostOperationType::GET_SHOWED_SECTIONS_NUMS)::Route(proId).GetData<int>() > 0) {
                    CreateAnimationByCorssEx();
                    return;
                }
                if (d->isStop) {
                    d->isAddFieldData = false;
                    if (!CreateAnimationByTimes()) {
                        return;
                    }
                }
                SetProbeStatus(false);
                d->isUpdateProgress = true;
                d->isPlay = true;
                SetBtnStyle(d->playPauseBtn, "AnimationPlayBtn.svg", QStringLiteral(u"暂停"));
                SlotPlayOrPause(false);
                ROUTER(SimPostOperationType::SET_ANIMATION_ACTIONS)::Route(proId, Base::AnimationActionType::PLAY);
                d->stopBtn->setEnabled(true);
            }
        });

        d->stopBtn = new QPushButton();
        SetBtnStyle(d->stopBtn, "AnimationStopBtn.svg", QStringLiteral(u"停止"));
        connect(d->stopBtn, &QPushButton::clicked, [this]() {
            SetProbeStatus(true);
            d->isStop = true;
            if (d->isPlay) {
                d->isPlay = false;
                SetBtnStyle(d->playPauseBtn, "AnimationPauseBtn.svg", QStringLiteral(u"播放"));
            }
            SlotPlayOrPause(true);
            Base::ProjectIDType pId =
                ROUTER(ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
            ROUTER(SimPostOperationType::STOP_ANIMATION)::Route(pId, true);
            d->stopBtn->setEnabled(false);
        });
    }

    void SimAnimationWidget::InitItems()
    {
        d->jumpFirstFrame = new QPushButton();
        SetBtnStyle(d->jumpFirstFrame, "JumpFirstFrame.svg", QStringLiteral(u"跳到第一帧"));
        connect(d->jumpFirstFrame, &QPushButton::clicked, [this]() {
            d->pointInTime->setCurrentIndex(0);
            SlotProgressReleased();
        });

        d->jumpForwardNFrames = new QPushButton();
        SetBtnStyle(d->jumpForwardNFrames, "JumpForwardNFrames.svg", QStringLiteral(u"向前1帧"));
        connect(d->jumpForwardNFrames, &QPushButton::clicked, [this]() {
            int currentIndex = d->pointInTime->currentIndex();
            int maxIndex = d->pointInTime->count() - 1;
            int newIndex = (currentIndex + maxIndex) % (maxIndex + 1); // 使用模运算实现循环，注意这里要加上maxIndex再取模
            d->pointInTime->setCurrentIndex(newIndex);
            SlotProgressReleased();
        });
        InitPlayPauseItems();
    }

    void SimAnimationWidget::InitLayout()
    {
        d->hLayoutPlay->addWidget(d->jumpFirstFrame, 0);
        d->hLayoutPlay->addStretch(1);
        d->hLayoutPlay->addWidget(d->jumpForwardNFrames);
        d->hLayoutPlay->addStretch(1);
        d->hLayoutPlay->addWidget(d->playPauseBtn);
        d->hLayoutPlay->addStretch(1);
        d->hLayoutPlay->addWidget(d->stopBtn);
        d->hLayoutPlay->addStretch(1);
        d->hLayoutPlay->addWidget(d->jumpBackwardNFrames);
        d->hLayoutPlay->addStretch(1);
        d->hLayoutPlay->addWidget(d->jumpLastFrame, 0);

        d->progress = new QSlider();
        d->progress->setOrientation(Qt::Orientation::Horizontal);
        d->progress->setFixedWidth(COMBOBOX_WIDTH);
        d->progress->setStyleSheet(PROGRESS_STYLE);
        d->progress->setPageStep(0);
        d->pointInTime = new QComboBox();
        d->pointInTime->setEditable(true);
        d->pointInTime->lineEdit()->setReadOnly(true);
        SetStyleSheet(d->pointInTime, QCOMBOBOX_STYLE);
        d->frameRate = new QSlider();
        d->frameRate->setOrientation(Qt::Orientation::Horizontal);
        // 创建滑块并设置范围
        d->frameRate->setRange(1, 100); // 默认范围 1-100
        // 设置刻度显示位置和间隔
        d->frameRate->setTickPosition(QSlider::TicksBelow);
        d->frameRate->setTickInterval(20); // 20 加1刻度
        d->frameRate->setFixedHeight(BTN_FRAME_SIZE);
        d->frameRate->setStyleSheet(FRAMES_STYLE);
        d->frameLabel = new QLabel();

        d->hLayoutSlider->addWidget(d->progress);
        d->hLayoutSlider->addWidget(d->pointInTime);
        d->hLayoutFrameRate->addWidget(d->frameRate);
        d->hLayoutFrameRate->addWidget(d->frameLabel);

        QVBoxLayout *verticalLayout = new QVBoxLayout();
        verticalLayout->setMargin(0);
        verticalLayout->setSpacing(10);
        verticalLayout->addLayout(d->hLayoutPlay);
        verticalLayout->addLayout(d->hLayoutSlider);
        verticalLayout->addLayout(d->hLayoutFrameRate);

        d->exportLabel = new QLabel();
        d->exportLabel->setText(QStringLiteral(u"导出"));
        d->exportLabel->setAlignment(Qt::AlignCenter);
        QVBoxLayout *btnLayout = new QVBoxLayout();
        btnLayout->addWidget(d->exportBtn);
        btnLayout->addWidget(d->exportLabel);
        btnLayout->addStretch();

        QHBoxLayout *allHorizontalLayout = new QHBoxLayout(this);
        allHorizontalLayout->setMargin(0);
        allHorizontalLayout->setSpacing(15); // 15间距
        allHorizontalLayout->addLayout(verticalLayout);
        allHorizontalLayout->addLayout(btnLayout);
        this->setLayout(allHorizontalLayout);
    }

    void SimAnimationWidget::CreateItems()
    {
        this->setObjectName("simAnimationWidget");
        setFixedWidth(WIDTH);
        d->hLayoutPlay = new QHBoxLayout();
        d->hLayoutSlider = new QHBoxLayout();
        d->hLayoutFrameRate = new QHBoxLayout();

        InitItems();

        d->jumpBackwardNFrames = new QPushButton();
        SetBtnStyle(d->jumpBackwardNFrames, "JumpBackwardNFrames.svg", QStringLiteral(u"向后1帧"));
        connect(d->jumpBackwardNFrames, &QPushButton::clicked, [this]() {
            int currentIndex = d->pointInTime->currentIndex();
            int maxIndex = d->pointInTime->count() - 1;
            d->pointInTime->setCurrentIndex((currentIndex + 1) % (maxIndex + 1));
            SlotProgressReleased();
        });

        d->jumpLastFrame = new QPushButton();
        SetBtnStyle(d->jumpLastFrame, "JumpLastFrame.svg", QStringLiteral(u"跳到最后一帧"));
        connect(d->jumpLastFrame, &QPushButton::clicked, [this]() {
            int lastIndex = d->pointInTime->count() - 1;
            d->pointInTime->setCurrentIndex(lastIndex);
            SlotProgressReleased();
        });
        d->exportBtn = new QToolButton();
        d->exportBtn->setFixedSize(40, 40); // 40 图标大小
        QIcon icon = GetImageIcon("AnimationExportBtn.svg");
        d->exportBtn->setIcon(icon);
        d->exportBtn->setIconSize(QSize(32, 32)); // 32 图片大小
        d->exportBtn->setToolTip(QStringLiteral(u"动画导出"));
        InitLayout();

        SetAllButtonEnable(false);
        // 双向绑定信号槽
        connect(d->pointInTime, QOverload<int>::of(&QComboBox::currentIndexChanged),
            d->progress, &QSlider::setValue);
        connect(d->progress, &QSlider::valueChanged,
            d->pointInTime, &QComboBox::setCurrentIndex);
        connect(d->pointInTime, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, &SimAnimationWidget::SlotUpdateFrameStatus);
        connect(this, &SimAnimationWidget::UpdateProgressCombox, this,
            &SimAnimationWidget::SlotUpdateProgressCombox, Qt::QueuedConnection);
        connect(d->frameRate, &QSlider::valueChanged, [this](int value) {
            d->frameLabel->setText(QString::number(value));
            SlotFrameRateReleased();
        });
        connect(d->progress, &QSlider::sliderReleased, this, &SimAnimationWidget::SlotProgressReleased);
        connect(d->pointInTime, QOverload<int>::of(&QComboBox::activated),
            this, &SimAnimationWidget::SlotProgressReleased);
        connect(d->exportBtn, &QPushButton::clicked, this, &SimAnimationWidget::SlotExportBtn);
        SetFrameRate(10); // 10 初始化
    }

    void SimAnimationWidget::SlotProgressReleased()
    {
        d->isAddFieldData = false;
        if (!CreateAnimationByTimes(false)) {
            return;
        }
        Base::ProjectIDType pId =
            ROUTER(ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        ROUTER(SimPostOperationType::SEND_PROGRESS_INDEX)::Route(pId, d->pointInTime->currentIndex());
    }
    void SimAnimationWidget::SetFrameRate(int fps)
    {
        if (fps <= 0 || fps > 1000) return;
        const QSignalBlocker blocker(d->frameRate);
        d->frameRate->setMaximum(qMax(100, fps));
        d->frameRate->setValue(fps);
        d->frameLabel->setText(QString::number(fps));
    }

    void SimAnimationWidget::SyncFrameRate()
    {
        const auto projectId = ROUTER_NO_RECORD(ProjectOperationType::GET_CURRENT_PROJECT_ID)
            ::Route().GetData<Base::ProjectIDType>();
        if (projectId < 0) return;
        Painter::RenderManager::GetInstance().ProcessInProject(projectId, [this](Painter::RenderProvider &provider) {
            using namespace Painter;
            auto renderer = GetConcreteRenderer<AnimationRenderer>(provider.GetAllRenderer()).lock();
            if (renderer) SetFrameRate(static_cast<int>(renderer->GetFrameRate()));
        });
    }

    void SimAnimationWidget::SlotFrameRateReleased()
    {
        Base::ProjectIDType pId =
            ROUTER(ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        ROUTER(SimPostOperationType::SEND_FRAME_RATE)::Route(pId, d->frameRate->value());
    }

    bool ContainsChinese(const QString &str)
    {
        return str.contains(QRegExp("[\\x4e00-\\x9fa5]+"));
    }

    void SimAnimationWidget::SlotExportBtn()
    {
        qInfo(UI) << tr("Export does not support Chinese paths or Chinese names.");
        QString filePath = Gui::GetSaveFileName(nullptr, "Save File", "avi(*.avi)");
        if (filePath.isEmpty()) {
            return;
        }
        if (ContainsChinese(filePath)) {
            qCritical(UI) << tr("Export does not support Chinese paths or Chinese names.");
            return;
        }
        QDir fileDir(filePath);
        QString absPath = fileDir.absoluteFilePath(filePath);
        if (QFile(absPath).exists()) {
            QFile file(absPath);
            file.remove(); // 文件存在先删除
        }
        qInfo(UI) << tr("%1 file exporting, please wait.").arg(filePath);
        d->isAddFieldData = false;
        if (!CreateAnimationByTimes(false)) {
            return;
        }
        Base::ProjectIDType pId =
            ROUTER(ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        ROUTER(SimPostOperationType::EXPORT_ANIMATION_DATA)::Route(pId, filePath, d->frameRate->value());
    }

    void SimAnimationWidget::SlotUpdateFrameStatus(int index)
    {
        if (d->isPlay) {
            return;
        }
        d->jumpFirstFrame->setEnabled(true);
        d->jumpLastFrame->setEnabled(true);
        if (index == 0) { // 第一帧
            d->jumpFirstFrame->setEnabled(false);
        }
        if (index == d->pointInTime->count() - 1) { // 最后一帧
            d->jumpLastFrame->setEnabled(false);
        }
    }

    void SimAnimationWidget::SlotUpdateProgressCombox(int index)
    {
        if (!d->isUpdateProgress || index < 0) {
            return;
        }
        d->pointInTime->setCurrentIndex(index);
    }

    void SimAnimationWidget::SlotPlayOrPause(bool enable)
    {
        d->jumpFirstFrame->setEnabled(enable);
        d->jumpForwardNFrames->setEnabled(enable);
        d->jumpBackwardNFrames->setEnabled(enable);
        d->jumpLastFrame->setEnabled(enable);
        d->progress->setEnabled(enable);
        d->pointInTime->setEnabled(enable);
    }

    void SimAnimationWidget::SetAllButtonEnable(bool enable)
    {
        d->currId =
            ROUTER(ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        d->playPauseBtn->setEnabled(enable);
        d->stopBtn->setEnabled(enable);
        SlotPlayOrPause(enable);
        d->exportBtn->setEnabled(enable);
        d->frameRate->setEnabled(enable);
        SyncFrameRate();
        if (d->isPlay) {
            d->isPlay = false;
            SetBtnStyle(d->playPauseBtn, "AnimationPauseBtn.svg", QStringLiteral(u"暂停"));
        }
    }

    void SimAnimationWidget::SetTimeOrFreqs(const QStringList &list, const QString &curText)
    {
        if (d == nullptr || d->pointInTime == nullptr) {
            return;
        }
        d->pointInTime->clear();
        if (list.size() == 0) {
            d->progress->setRange(0, 0);
            return;
        }
        d->pointInTime->addItems(list);
        for (int i = 0; i < list.size(); i++) {
            d->pointInTime->setItemData(i, list[i], Qt::ToolTipRole);
        }
        d->progress->setRange(0, d->pointInTime->count() - 1);
        int index = d->pointInTime->findText(curText);
        if (index != -1) {
            d->pointInTime->setCurrentIndex(index);
        }
    }

    void SimAnimationWidget::SetComboxIndex(const int &index)
    {
        if (!d->isUpdateProgress) {
            return;
        }
        Q_EMIT UpdateProgressCombox(index);
    }
    void SimAnimationWidget::StopAnimation()
    {
        d->isUpdateProgress = false;
        d->isStop = true;
        SetProbeStatus(true);
        // 使用 ROUTER_NO_RECORD: 此方法被 SimPostDisplacementsTable::ButtonClicked(630行)
        // 和 SimPostContainer::SetAnimationEnable(364行) 自动调用("更新前先停止播放"),
        // 非用户主动操作, 不录制宏。用户主动点击停止按钮走 444 行的 ROUTER 路径录制。
        ROUTER_NO_RECORD(SimPostOperationType::STOP_ANIMATION)::Route(d->currId, false);
    }
    void SimAnimationWidget::CreateAnimationByCorssEx()
    {
        StopAnimation();

        Base::ProjectIDType projectId =
            ROUTER(Route::ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        const Base::FieldOutputItemPtr simPostPtr = GetCurrentPtr(projectId).dynamicCast<Base::FieldOutputItem>();

        QStringList splitTmp = simPostPtr->value.split("$");
        QString curIndex = "";
        if (splitTmp.size() == INDEX_3RD) {
            curIndex = splitTmp.last();
        }
        SetAllButtonEnable(true);
        SetTimeOrFreqs(simPostPtr->timesOrFreqs, curIndex);

        d->isAddFieldData = true;
        if (!CreateAnimationByTimes()) {
            return;
        }
        SetProbeStatus(false);
        d->isUpdateProgress = true;
        d->isPlay = true;
        SetBtnStyle(d->playPauseBtn, "AnimationPlayBtn.svg", QStringLiteral(u"暂停"));
        SlotPlayOrPause(false);
        Base::ProjectIDType pId =
            ROUTER(ProjectOperationType::GET_CURRENT_PROJECT_ID)::Route().GetData<Base::ProjectIDType>();
        ROUTER(SimPostOperationType::SET_ANIMATION_ACTIONS)::Route(pId, Base::AnimationActionType::PLAY);
        d->stopBtn->setEnabled(true);
        d->playPauseBtn->setEnabled(true);
    }
    void SimAnimationWidget::CreateAnimationByCorss()
    {
        if (!d->isPlay) {
            return;
        }
        CreateAnimationByCorssEx();
    }
}