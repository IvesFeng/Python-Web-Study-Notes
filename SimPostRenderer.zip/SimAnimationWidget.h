/*
* Copyright (c) Huawei Technologies Co., Ltd. 2025-2025. All rights reserved.
*/
#ifndef SIM_ANIMATION_WIDGET_H
#define SIM_ANIMATION_WIDGET_H
#include "Application.h"
#include <QWidget>
#include <QLabel>
namespace Gui {
    QT_FORWARD_DECLARE_STRUCT(SimAnimationWidgetPrivateData);
    class SimAnimationWidget : public QWidget {
        Q_OBJECT
    public:
        static SimAnimationWidget *GetInstance();

        void SetAllButtonEnable(bool enable);
        void SlotPlayOrPause(bool enable);
        void SetTimeOrFreqs(const QStringList &list, const QString &curText);
        void SetComboxIndex(const int &index);
        void SetFrameRate(int fps);
        void SyncFrameRate();
        void StopAnimation();
        void CreateAnimationByCorss();
        bool CreateAnimationByTimes(bool isSendDefor = true);
        bool CheckLoadH5DatasIsOOM(Base::ProjectIDType projectId,
            double retSize, const QVector<Base::ItemIdType> &createItemIds);
    private:
        explicit SimAnimationWidget(QWidget *parent = nullptr);
        ~SimAnimationWidget();
    private:
        void CreateItems();
        void InitItems();
        void InitPlayPauseItems();
        void SetProbeStatus(bool isShow);
        void CheckIsShowWaitLab(Base::ProjectIDType projectId,
            QLabel *waitStatusLab);
        void InitLayout();
        void CreateAnimationByCorssEx();
        int CreateNewFieldDatas(const Base::FieldOutputItemPtr simPostPtr,
            Base::ItemIdType stepItemId, const QString &baseName, const QString &timeFreq);

    public Q_SLOTS:
        void SlotUpdateProgressCombox(int index);
        void SlotUpdateFrameStatus(int index);
        void SlotExportBtn();
        void SlotProgressReleased();
        void SlotFrameRateReleased();
    Q_SIGNALS:
        void UpdateProgressCombox(int index);
    private:
        static SimAnimationWidget *instance;
        QScopedPointer<SimAnimationWidgetPrivateData> d;
    };
}
#endif // !SIM_ANIMATION_WIDGET_H